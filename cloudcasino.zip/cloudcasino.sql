-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2026 at 04:39 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cloudcasino`
--

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` bigint(20) UNSIGNED NOT NULL,
  `action` varchar(255) NOT NULL,
  `target_type` varchar(255) NOT NULL,
  `target_id` varchar(255) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `backups`
--

CREATE TABLE `backups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL,
  `format` varchar(255) NOT NULL,
  `scope` varchar(255) NOT NULL DEFAULT 'manual',
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `size_bytes` bigint(20) UNSIGNED DEFAULT NULL,
  `storage_path` varchar(255) DEFAULT NULL,
  `error` text DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `backups`
--

INSERT INTO `backups` (`id`, `type`, `format`, `scope`, `status`, `size_bytes`, `storage_path`, `error`, `meta`, `created_by`, `completed_at`, `expires_at`, `created_at`) VALUES
(1, 'full', 'zip', 'manual', 'success', 112047, 'backups/full/full-manual-20260812-165657.zip', NULL, NULL, NULL, '2026-08-12 10:56:57', NULL, '2026-08-12 10:56:57'),
(2, 'full', 'zip', 'manual', 'success', 112160, 'backups/full/full-manual-20260812-165733.zip', NULL, NULL, NULL, '2026-08-12 10:57:33', NULL, '2026-08-12 10:57:33');

-- --------------------------------------------------------

--
-- Table structure for table `backup_downloads`
--

CREATE TABLE `backup_downloads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `backup_id` bigint(20) UNSIGNED NOT NULL,
  `admin_id` bigint(20) UNSIGNED NOT NULL,
  `ip` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cache`
--

INSERT INTO `cache` (`key`, `value`, `expiration`) VALUES
('laravel-cache-jwt_blacklist_c6f38ee5-bfbf-4406-ac76-e762e1ac1363', 'b:1;', 1790347027);

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `email_templates`
--

CREATE TABLE `email_templates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL DEFAULT 'custom',
  `transaction_type` varchar(255) DEFAULT NULL,
  `trigger_event` varchar(255) NOT NULL DEFAULT 'manual',
  `subject` varchar(255) NOT NULL,
  `body_html` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `export_requests`
--

CREATE TABLE `export_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `manager_id` bigint(20) UNSIGNED NOT NULL,
  `export_type` varchar(255) NOT NULL DEFAULT 'transactions',
  `filters` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`filters`)),
  `reason` text DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `row_count` int(10) UNSIGNED DEFAULT NULL,
  `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `admin_note` text DEFAULT NULL,
  `approved_expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fast_payment_api_logs`
--

CREATE TABLE `fast_payment_api_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `fast_payment_transaction_id` bigint(20) UNSIGNED DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `provider_reference` varchar(255) DEFAULT NULL,
  `http_status` smallint(5) UNSIGNED DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `request_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_payload`)),
  `response_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_payload`)),
  `signature_valid` tinyint(1) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `fast_payment_api_logs`
--

INSERT INTO `fast_payment_api_logs` (`id`, `fast_payment_transaction_id`, `provider`, `user_id`, `provider_reference`, `http_status`, `action`, `request_payload`, `response_payload`, `signature_valid`, `success`, `error_message`, `duration_ms`, `created_at`) VALUES
(1, NULL, 'FAST Payment', 3, 'FP202609021813543486', 200, 'create_payment', '{\"order_sn\":\"FP202609021813543486\",\"user_name\":\"engmdsah\",\"is_cash\":\"1\",\"is_pay\":\"1\",\"amount\":\"4.99\",\"notify_url\":\"http:\\/\\/localhost\\/api\\/webhooks\\/fast-payment\",\"ip\":\"127.0.0.1\",\"merchant_id\":\"1092768610\"}', '{\"outer_order_sn\":\"FP202609021813543486\",\"amount\":\"4.99\",\"fee\":\"0.95\",\"pay_url\":\"https:\\/\\/cash.app\\/$88888888\",\"status\":\"00000\",\"msg\":\"Submission successful\",\"merchant_id\":\"1092768610\",\"sign\":\"9D54BB79F216A9751E9DD70F8D2C1697\"}', 1, 1, NULL, 1608, '2026-09-02 12:13:56'),
(2, NULL, 'FAST Payment', 3, 'FP202609021856256860', 200, 'create_payment', '{\"order_sn\":\"FP202609021856256860\",\"user_name\":\"engmdsah\",\"is_cash\":\"1\",\"is_pay\":\"1\",\"amount\":\"4.99\",\"notify_url\":\"http:\\/\\/localhost\\/api\\/webhooks\\/fast-payment\",\"ip\":\"127.0.0.1\",\"merchant_id\":\"1092768610\"}', '{\"outer_order_sn\":\"FP202609021856256860\",\"amount\":\"4.99\",\"fee\":\"0.95\",\"pay_url\":\"https:\\/\\/cash.app\\/$88888888\",\"status\":\"00000\",\"msg\":\"Submission successful\",\"merchant_id\":\"1092768610\",\"sign\":\"E35D58C13CB0AD7BF8D9D0FDC3EB50B2\"}', 1, 1, NULL, 1513, '2026-09-02 12:56:26'),
(3, NULL, 'FAST Payment', 3, 'FP202609021916324529', 200, 'create_payment', '{\"order_sn\":\"FP202609021916324529\",\"user_name\":\"engmdsah\",\"is_cash\":\"1\",\"is_pay\":\"1\",\"amount\":\"4.99\",\"notify_url\":\"http:\\/\\/localhost\\/api\\/webhooks\\/fast-payment\",\"ip\":\"127.0.0.1\",\"merchant_id\":\"1092768610\"}', '{\"status\":\"90001\",\"msg\":\"the sign is incorrect\"}', 0, 0, 'the sign is incorrect', 1292, '2026-09-02 13:16:34');

-- --------------------------------------------------------

--
-- Table structure for table `fast_payment_transactions`
--

CREATE TABLE `fast_payment_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transaction_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `order_sn` varchar(255) NOT NULL,
  `fast_transaction_id` varchar(255) DEFAULT NULL,
  `provider` enum('cashapp','applepay','googlepay') NOT NULL,
  `requested_amount` decimal(12,2) NOT NULL,
  `confirmed_amount` decimal(12,2) DEFAULT NULL,
  `payment_status` enum('pending','completed','failed','cancelled') NOT NULL DEFAULT 'pending',
  `pay_url` text DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `device_id` varchar(255) DEFAULT NULL,
  `raw_response` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`raw_response`)),
  `confirmed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `games`
--

CREATE TABLE `games` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `username_suffix` varchar(10) DEFAULT NULL,
  `api_provider` varchar(255) DEFAULT NULL COMMENT 'orion_stars, game_agent, fast_api, river_pay, custom',
  `description` text DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `download_url` varchar(255) DEFAULT NULL,
  `web_url` varchar(255) DEFAULT NULL,
  `android_url` varchar(255) DEFAULT NULL,
  `ios_url` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `games`
--

INSERT INTO `games` (`id`, `name`, `username_suffix`, `api_provider`, `description`, `image_url`, `download_url`, `web_url`, `android_url`, `ios_url`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Cash Machine', 'CM', NULL, 'Fast-paced reel action with instant multipliers and big jackpots.', 'https://images.unsplash.com/photo-1518609878373-06d740f60d8b?w=800&auto=format&fit=crop', 'https://cashmachine.game', 'https://cashmachine777.com/play', 'https://cashmachine.game/apk', 'https://cashmachine.game/ios', 1, '2026-08-01 12:55:10', '2026-08-08 13:06:26'),
(2, 'Fire Kirin', 'FK', NULL, 'Popular fish hunter game with huge jackpots and bonus rounds.', 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop', 'https://firekirin.xyz', 'https://firekirin.xyz/play', 'https://firekirin.xyz/apk', 'https://firekirin.xyz/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(3, 'Game Room', 'GR', NULL, 'All-in-one arcade gaming hub featuring slots, fish tables, and keno.', 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop', 'https://gameroom777.com', 'https://gameroom777.com/play', 'https://gameroom777.com/apk', 'https://gameroom777.com/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(4, 'Game Vault', 'GV', NULL, 'High payouts and exciting bonus multipliers for top players.', 'https://images.unsplash.com/photo-1538481199705-c710c4e965fc?w=800&auto=format&fit=crop', 'https://gamevault999.com', 'https://gamevault999.com', 'https://gamevault999.com/apk', 'https://gamevault999.com/ios', 1, '2026-08-01 12:55:10', '2026-08-11 12:48:24'),
(5, 'Juwa', 'JW', NULL, 'Classic sweepstakes slots & fish tables with daily rewards.', 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=800&auto=format&fit=crop', 'https://juwa777.com', 'https://juwa777.com/web', 'https://juwa777.com/android', 'https://juwa777.com/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(6, 'Milky Way', 'MW', NULL, 'Intergalactic sweepstakes gaming experience with high multipliers.', 'https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?w=800&auto=format&fit=crop', 'https://milkywayapp.xyz', 'https://milkywayapp.xyz/play', 'https://milkywayapp.xyz/apk', 'https://milkywayapp.xyz/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(7, 'Orion Star', 'OS', NULL, 'Fast-paced action slots, reel games and interactive fish tables.', 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop', 'https://orionstars.vip', 'https://orionstars.vip/play', 'https://orionstars.vip/apk', 'https://orionstars.vip/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(8, 'Panda Master', 'PM', NULL, 'Vibrant graphics, progressive jackpots, and instant prizes.', 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop', 'https://pandamaster.vip', 'https://pandamaster.vip/web', 'https://pandamaster.vip/apk', 'https://pandamaster.vip/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10'),
(9, 'River Sweeps', 'RS', NULL, 'Premier sweepstakes casino games with spinning reels and bonus wins.', 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop', 'https://riversweeps.org', 'https://riversweeps.org/play', 'https://riversweeps.org/apk', 'https://riversweeps.org/ios', 1, '2026-08-01 12:55:10', '2026-08-01 12:55:10');

-- --------------------------------------------------------

--
-- Table structure for table `game_accounts`
--

CREATE TABLE `game_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `game_id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `provider_account_id` varchar(100) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `web_login_url` varchar(255) DEFAULT NULL,
  `status` enum('available','assigned','locked') NOT NULL DEFAULT 'available',
  `assigned_to` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_accounts`
--

INSERT INTO `game_accounts` (`id`, `game_id`, `username`, `provider_account_id`, `password_hash`, `web_login_url`, `status`, `assigned_to`, `created_at`, `updated_at`) VALUES
(38, 1, 'engmdsahCM', NULL, '11223344', 'https://cashmachine777.com/play', 'assigned', NULL, '2026-08-27 09:22:32', '2026-09-12 07:44:03'),
(39, 2, 'engmdsahFK', NULL, '1o8OQElDFD', 'https://firekirin.xyz/play', 'assigned', NULL, '2026-09-12 07:35:23', '2026-09-12 07:35:23');

-- --------------------------------------------------------

--
-- Table structure for table `game_api_logs`
--

CREATE TABLE `game_api_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `provider_id` bigint(20) UNSIGNED DEFAULT NULL,
  `provider_name` varchar(255) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `endpoint` varchar(255) DEFAULT NULL,
  `provider_reference` varchar(255) DEFAULT NULL,
  `request_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_payload`)),
  `response_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_payload`)),
  `http_status` int(11) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `related_user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `related_transaction_id` bigint(20) UNSIGNED DEFAULT NULL,
  `related_request_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_api_logs`
--

INSERT INTO `game_api_logs` (`id`, `provider_id`, `provider_name`, `action`, `endpoint`, `provider_reference`, `request_payload`, `response_payload`, `http_status`, `success`, `error_message`, `duration_ms`, `related_user_id`, `related_transaction_id`, `related_request_id`, `created_at`) VALUES
(1, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":430,\"message\":\"Username or password error\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Username or password error). Retried 8 times with multipart and urlencoded encodings.', 23362, NULL, NULL, NULL, '2026-08-10 11:54:26'),
(2, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":430,\"message\":\"Username or password error\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Username or password error). Retried 8 times with multipart and urlencoded encodings.', 22919, NULL, NULL, NULL, '2026-08-10 11:54:49'),
(3, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20358, NULL, NULL, NULL, '2026-08-10 11:55:15'),
(4, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 19623, NULL, NULL, NULL, '2026-08-10 11:55:35'),
(5, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20396, NULL, NULL, NULL, '2026-08-10 12:07:38'),
(6, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20149, NULL, NULL, NULL, '2026-08-10 12:08:00'),
(7, 1, 'gameroom777', 'agent_login', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20465, NULL, NULL, NULL, '2026-08-10 12:21:34'),
(8, 1, 'gameroom777', 'agent_login', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 20365, NULL, NULL, NULL, '2026-08-10 12:22:07'),
(9, 1, 'gameroom777', 'agent_login', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 19340, NULL, NULL, NULL, '2026-08-10 12:34:30'),
(10, 1, 'gameroom777', 'agent_login', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":400,\"message\":\"Too many login errors, please try again in an hour\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Too many login errors, please try again in an hour). Retried 8 times with multipart and urlencoded encodings.', 19315, NULL, NULL, NULL, '2026-08-10 12:35:33'),
(11, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":430,\"message\":\"Username or password error\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Username or password error). Retried 8 times with multipart and urlencoded encodings.', 22447, NULL, NULL, NULL, '2026-08-11 10:26:38'),
(12, 1, 'gameroom777', 'test', '/api/agent/login', NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":430,\"message\":\"Username or password error\"}', 200, 0, 'Upstream connection issue (urlencoded: HTTP 200 Username or password error). Retried 8 times with multipart and urlencoded encodings.', 26987, NULL, NULL, NULL, '2026-08-11 10:27:05'),
(13, 2, 'gamevault999', 'test', '/api/agent/login', NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"\"}). Retried 8 times with multipart and urlencoded encodings.', 28237, NULL, NULL, NULL, '2026-08-11 10:35:06'),
(14, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1731, NULL, NULL, NULL, '2026-08-11 10:55:22'),
(15, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1293, NULL, NULL, NULL, '2026-08-11 12:11:43'),
(16, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1084, NULL, NULL, NULL, '2026-08-11 12:16:00'),
(17, 1, 'gameroom777', 'test', NULL, NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":200,\"message\":\"Users login succeeded\",\"data\":{\"userName\":\"teststore22\",\"money\":\"100.00\",\"token\":\"[REDACTED]\",\"expires_time\":1786494248}}', 200, 1, NULL, 3452, NULL, NULL, NULL, '2026-08-11 12:24:09'),
(18, 1, 'gameroom777', 'e2e_create_player', NULL, NULL, '{\"username\":\"TESTGR_msozpmtdae2\",\"nickname\":\"TESTGR_msozpmtdae2\"}', '{\"status_code\":400,\"message\":\"Nickname can only be letters and numbers, and cannot exceed 20 characters\"}', 200, 0, 'Nickname can only be letters and numbers, and cannot exceed 20 characters', 7868, NULL, NULL, NULL, '2026-08-11 12:24:55'),
(19, 1, 'gameroom777', 'e2e_create_player', NULL, NULL, '{\"username\":\"TESTmsozr4ey94ee65\",\"nickname\":\"TESTmsozr4ey94ee65\"}', '{\"status_code\":400,\"message\":\"Username already exists\"}', 200, 0, 'Username already exists', 33242, NULL, NULL, NULL, '2026-08-11 12:26:30'),
(20, 1, 'gameroom777', 'e2e_create_player', NULL, NULL, '{\"username\":\"TESTmsozt937e63b14\",\"nickname\":\"TESTmsozt937e63b14\"}', '{\"status_code\":200,\"message\":\"Insert successful\",\"data\":{\"id\":3172648,\"account\":\"TESTmsozt937e63b14\",\"password\":\"[REDACTED]\",\"balance\":\"0\",\"time\":\"2026-08-11 13:27:44\"}}', 200, 1, NULL, 16037, NULL, NULL, NULL, '2026-08-11 12:27:52'),
(21, 1, 'gameroom777', 'e2e_player_list', NULL, NULL, '{\"username\":\"TESTmsozt937e63b14\"}', '{\"status_code\":200,\"message\":\"Query successful\",\"count\":4,\"data\":[{\"Account\":\"TESTmsozt937e63b14\",\"nickname\":\"TESTmsozt937e63b14\",\"AddDate\":\"2026-08-11 13:27:44\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172648,\"score\":0},{\"Account\":\"TESTmsozr4ey94ee65\",\"nickname\":\"TESTmsozr4ey94ee65\",\"AddDate\":\"2026-08-11 13:26:04\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172644,\"score\":0},{\"Account\":\"unknownGR\",\"nickname\":\"unknownGR\",\"AddDate\":\"2026-06-06 12:46:41\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3054418,\"score\":0},{\"Account\":\"soae2emq2mv95n30bu\",\"nickname\":\"soae2emq2mv95n30bu\",\"AddDate\":\"2026-06-06 12:34:59\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3054400,\"score\":0}]}', 200, 1, NULL, 1067, NULL, NULL, NULL, '2026-08-11 12:27:54'),
(22, 1, 'gameroom777', 'e2e_get_score', NULL, NULL, '{\"id\":3172648}', '{\"status_code\":200,\"message\":\"Query successful\",\"data\":{\"username\":\"TESTmsozt937e63b14\",\"balance\":0,\"is_game\":false}}', 200, 1, NULL, 1177, NULL, NULL, NULL, '2026-08-11 12:27:56'),
(23, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1233, NULL, NULL, NULL, '2026-08-11 12:32:11'),
(24, 1, 'gameroom777', 'test', NULL, NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":200,\"message\":\"Users login succeeded\",\"data\":{\"userName\":\"teststore22\",\"money\":\"100.00\",\"token\":\"[REDACTED]\",\"expires_time\":1786613017}}', 200, 1, NULL, 1512, NULL, NULL, NULL, '2026-08-12 21:23:37'),
(25, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1205, NULL, NULL, NULL, '2026-08-12 23:15:59'),
(26, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1049, NULL, NULL, NULL, '2026-08-12 23:16:09'),
(27, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1043, NULL, NULL, NULL, '2026-08-12 23:17:33'),
(28, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1067, NULL, NULL, NULL, '2026-08-12 23:23:23'),
(29, 1, 'gameroom777', 'test', NULL, NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":200,\"message\":\"Users login succeeded\",\"data\":{\"userName\":\"teststore22\",\"money\":\"100.00\",\"token\":\"[REDACTED]\",\"expires_time\":1786621115}}', 200, 1, NULL, 25528, NULL, NULL, NULL, '2026-08-12 23:38:36'),
(30, 1, 'gameroom777', 'e2e_create_player', NULL, NULL, '{\"username\":\"TESTmsr38nfo9385bd\",\"nickname\":\"TESTmsr38nfo9385bd\"}', '{\"status_code\":200,\"message\":\"Insert successful\",\"data\":{\"id\":3175020,\"account\":\"TESTmsr38nfo9385bd\",\"password\":\"[REDACTED]\",\"balance\":\"0\",\"time\":\"2026-08-13 00:39:13\"}}', 200, 1, NULL, 15115, NULL, NULL, NULL, '2026-08-12 23:39:21'),
(31, 1, 'gameroom777', 'e2e_player_list', NULL, NULL, '{\"username\":\"TESTmsr38nfo9385bd\"}', '{\"status_code\":200,\"message\":\"Query successful\",\"count\":8,\"data\":[{\"Account\":\"TESTmsr38nfo9385bd\",\"nickname\":\"TESTmsr38nfo9385bd\",\"AddDate\":\"2026-08-13 00:39:13\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3175020,\"score\":0},{\"Account\":\"sahadat77\",\"nickname\":\"sahadat77\",\"AddDate\":\"2026-08-11 13:55:41\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172673,\"score\":0},{\"Account\":\"TESTmsp0lv77c6f276\",\"nickname\":\"TESTmsp0lv77c6f276\",\"AddDate\":\"2026-08-11 13:49:57\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172665,\"score\":0},{\"Account\":\"engmdsah11\",\"nickname\":\"engmdsah11\",\"AddDate\":\"2026-08-11 13:48:20\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172663,\"score\":0},{\"Account\":\"TESTmsozt937e63b14\",\"nickname\":\"TESTmsozt937e63b14\",\"AddDate\":\"2026-08-11 13:27:44\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172648,\"score\":0},{\"Account\":\"TESTmsozr4ey94ee65\",\"nickname\":\"TESTmsozr4ey94ee65\",\"AddDate\":\"2026-08-11 13:26:04\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3172644,\"score\":0},{\"Account\":\"unknownGR\",\"nickname\":\"unknownGR\",\"AddDate\":\"2026-06-06 12:46:41\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3054418,\"score\":0},{\"Account\":\"soae2emq2mv95n30bu\",\"nickname\":\"soae2emq2mv95n30bu\",\"AddDate\":\"2026-06-06 12:34:59\",\"LoginCount\":0,\"lasttime\":\"-\",\"loginip\":\"-\",\"account_using\":1,\"id\":3054400,\"score\":0}]}', 200, 1, NULL, 19508, NULL, NULL, NULL, '2026-08-12 23:39:41'),
(32, 1, 'gameroom777', 'e2e_get_score', NULL, NULL, '{\"id\":3175020}', '{\"status_code\":200,\"message\":\"Query successful\",\"data\":{\"username\":\"TESTmsr38nfo9385bd\",\"balance\":0,\"is_game\":false}}', 200, 1, NULL, 1113, NULL, NULL, NULL, '2026-08-12 23:39:44'),
(33, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 3514, NULL, NULL, NULL, '2026-08-16 11:13:46'),
(34, 2, 'gamevault999', 'test', NULL, NULL, '{\"username\":\"Mcashier01\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1037, NULL, NULL, NULL, '2026-08-16 11:18:27'),
(35, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 19664, NULL, NULL, NULL, '2026-08-18 11:09:11'),
(36, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 19241, NULL, NULL, NULL, '2026-08-18 11:09:31'),
(37, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 18893, NULL, NULL, NULL, '2026-08-18 11:10:02'),
(38, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 18761, NULL, NULL, NULL, '2026-08-18 11:10:22'),
(39, 1, 'gameroom777', 'test', NULL, NULL, '{\"username\":\"Teststore22\"}', '{\"status_code\":200,\"message\":\"Users login succeeded\",\"data\":{\"userName\":\"teststore22\",\"money\":\"100.00\",\"token\":\"[REDACTED]\",\"expires_time\":1787094623}}', 200, 1, NULL, 1440, NULL, NULL, NULL, '2026-08-18 11:10:23'),
(40, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 18666, NULL, NULL, NULL, '2026-08-18 11:10:55'),
(41, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/title>\\n  <style>\\n    * {\\n      margin: 0;\\n      padding: 0;\\n      box-sizing: border-box;\\n    }\\n\\n    body {\\n      font-family: \'Microsoft YaHei\', Arial, sans-serif;\\n      background-color: #f8f9fa;\\n      display: flex;\\n      justify-content: center;\\n      align-items: center;\\n      min-height: 100vh;\\n      padding: 20px;\\n    }\\n\\n    .error-container {\\n      background: white;\\n      border-radius: 10px;\\n      box-shadow: 0 0 30px rgba(0, 0, 0, 0.1);\\n      padding: 40px;\\n      text-align: center;\\n      max-width: 600px;\\n      width: 100%;\\n    }\\n\\n    .error-icon {\\n      font-size: 72px;\\n      color: #dc3545;\\n      margin-bottom: 20px;\\n    }\\n\\n    .error-title {\\n      font-size: 28px;\\n      color: #333;\\n      margin-bottom: 15px;\\n      font-weight: bold;\\n    }\\n\\n    .error-message {\\n      font-size: 18px;\\n      color: #666;\\n      line-height: 1.6;\\n      margin-bottom: 25px;\\n    }\\n\\n    .error-details {\\n      background-color: #f8d7da;\\n      border: 1px solid #f5c6cb;\\n      color: #721c24;\\n      border-radius: 5px;\\n      padding: 15px;\\n      margin: 20px 0;\\n      text-align: left;\\n      font-size: 14px;\\n    }\\n\\n    .error-code {\\n      font-family: monospace;\\n      background-color: #f1f1f1;\\n      padding: 2px 6px;\\n      border-radius: 3px;\\n    }\\n\\n    .contact-info {\\n      margin-top: 30px;\\n      font-size: 14px;\\n      color: #888;\\n    }\\n\\n    .back-button {\\n      display: inline-block;\\n      background-color: #007bff;\\n      color: white;\\n      padding: 12px 30px;\\n      text-decoration: none;\\n      border-radius: 5px;\\n      font-size: 16px;\\n      transition: background-color 0.3s;\\n      margin-top: 10px;\\n    }\\n\\n    .back-button:hover {\\n      background-color: #0056b3;\\n    }\\n\\n    @media (max-width: 600px) {\\n      .error-container {\\n        padding: 20px;\\n      }\\n\\n      .error-title {\\n        font-size: 24px;\\n      }\\n\\n      .error-message {\\n        font-size: 16px;\\n      }\\n    }\\n  <\\/style>\\n<\\/head>\\n\\n<body>\\n  <div class=\\\"error-container\\\">\\n    <div class=\\\"error-icon\\\">\\u26a0\\ufe0f<\\/div>\\n    <h1 class=\\\"error-title\\\">System Under Maintenance<\\/h1>\\n    <p class=\\\"error-message\\\">We\'re sorry, but the current page is temporarily unavailable. Please try again later.<\\/p>\\n\\n    <div class=\\\"error-details\\\">\\n      <strong>Error Details:<\\/strong><br>\\n      The system is currently under maintenance. Some features may be unavailable.<br>\\n      Error Code: <span class=\\\"error-code\\\">MAINTENANCE_503<\\/span>\\n    <\\/div>\\n  <\\/div>\\n<\\/body>\\n\\n<\\/html>\"}', 404, 0, 'Upstream connection issue (urlencoded: HTTP 404 {\"raw_text\":\"<!DOCTYPE html>\\n<html lang=\\\"zh-CN\\\">\\n\\n<head>\\n  <meta charset=\\\"UTF-8\\\">\\n  <meta name=\\\"viewport\\\" content=\\\"width=device-width, initial-scale=1.0\\\">\\n  <title>system maintenance<\\/t). Retried 8 times with multipart and urlencoded encodings.', 19063, NULL, NULL, NULL, '2026-08-18 11:11:14'),
(42, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1039, NULL, NULL, NULL, '2026-08-18 11:16:26'),
(43, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"Megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1023, NULL, NULL, NULL, '2026-08-18 11:17:01'),
(44, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"megacashier\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1021, NULL, NULL, NULL, '2026-08-18 11:17:11'),
(45, 3, 'juwa', 'test', NULL, NULL, '{\"username\":\"109961\"}', '{\"code\":5,\"msg\":\"Access ip is not white ip\",\"data\":[],\"count\":0}', 200, 0, 'Access ip is not white ip (code 5)', 1091, NULL, NULL, NULL, '2026-08-18 11:23:21'),
(46, 1, 'gameroom777', 'create_player', NULL, NULL, '{\"username\":\"engmdsahCM\",\"nickname\":\"engmdsahCM\"}', '{\"status_code\":200,\"message\":\"Insert successful\",\"data\":{\"id\":3204129,\"account\":\"engmdsahCM\",\"password\":\"[REDACTED]\",\"balance\":\"0\",\"time\":\"2026-08-27 10:22:24\"}}', 200, 1, NULL, 31657, NULL, NULL, NULL, '2026-08-27 09:22:32'),
(47, 2, 'gamevault999', 'agent_login', NULL, NULL, '{\"agent_username\":\"Mcashier01\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1179, NULL, NULL, NULL, '2026-08-27 09:35:03'),
(48, 2, 'gamevault999', 'agent_login', NULL, NULL, '{\"agent_username\":\"Mcashier01\"}', '{\"code\":2,\"msg\":\"Invalid request parameters\",\"data\":[],\"count\":0}', 200, 0, 'Invalid request parameters (code 2)', 1090, NULL, NULL, NULL, '2026-08-27 09:35:57'),
(49, 3, 'juwa', 'agent_login', NULL, NULL, '{\"agent_username\":\"109961\"}', '{\"code\":3,\"msg\":\"Invalid token\",\"data\":[],\"count\":0}', 200, 0, 'Invalid token (code 3)', 1141, NULL, NULL, NULL, '2026-08-27 09:36:06'),
(50, 4, 'orion_stars', 'agent_login', NULL, NULL, '{\"agent_username\":\"Mcashier01\"}', NULL, NULL, 0, 'Orion Stars API error [201]: Session timeout.', 1455, NULL, NULL, NULL, '2026-08-27 09:36:11'),
(51, 6, 'river_pay', 'agent_login', NULL, NULL, '{\"agent_username\":\"river_login\"}', NULL, NULL, 0, 'River Pay API request to [balance] failed: 403 <!DOCTYPE html>\n<html lang=\"en\">\n\n<head>\n	<meta charset=\"utf-8\">\n	<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/bootstrap.min.css\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/bootstrap-responsive.min.css\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/custom.css?v=1.12\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/datepicker/css/datepicker.css\" />\n<style type=\"text/css\">\n/*<![CDATA[*/\nbody {\r\n	background-image: url(\'/images/bg.png\');\r\n}\r\n		\r\n@media print {\r\n	body { padding: 0; margin: 0; background: none; }\r\n	a:link:after, a:visited:after { content: \"\"; }\r\n	.notforprint { display: none; }\r\n	.forprint { display: block; }\r\n	.for-print { display: block !important; }\r\n}\r\n\r\n@media screen {\r\n	.notforprint { display: block; }\r\n	.forprint { display: none; }\r\n}\n/*]]>*/\n</style>\n<script type=\"text/javascript\" src=\"/assets/f347dd98/jquery.min.js\"></script>\n<script type=\"text/javascript\" src=\"/lib/bootstrap/js/bootstrap.min.js\"></script>\n<script type=\"text/javascript\" src=\"/lib/datepicker/js/bootstrap-datepicker.js\"></script>\n<script type=\"text/javascript\" src=\"/js/shortcut.js\"></script>\n<script type=\"text/javascript\" src=\"/js/main.js?v=1.1.83\"></script>\n<script type=\"text/javascript\" src=\"/js/fp.min.js\"></script>\n<script type=\"text/javascript\" src=\"/js/fp-bootstrap.js\"></script>\n<title>Admin panel</title>\n	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n	<link rel=\"stylesheet\" href=\"/css/main.css?v=1.094\"/>\n</head>\n\n<body>\n	<div class=\"notforprint\">\r\n		<style type=\"text/css\">\n    body {\n        padding-top: 80px;\n        padding-bottom: 40px;\n    }\n</style>\n<div class=\"row-fluid\">\n	<div class=\"span6 offset3\">\n		<div class=\"alert alert-error\">\n			<h2>Error 403</h2>\n			<p>Access denied.</p>\n		</div>\n	</div>\n</div>\n<div class=\"row-fluid\">\n    <div class=\"span6 offset3\">\n        <a class=\"btn btn-primary\" href=\"/office/logout\"><i class=\"icon icon-white icon-refresh\"></i> Switch account</a>    </div>\n</div>\n	</div>\r\n	<div id=\"forprint\" class=\"forprint\"></div>\r\n<script type=\"module\" src=\"https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925\" integrity=\"sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==\" data-cf-beacon=\'{\"version\":\"2024.11.0\",\"token\":\"69a66274fbdc40c58dd0607c3fc7f8a1\"}\' crossorigin=\"anonymous\"></script>\n</body>\n\n</html>\n (a business error here can be normal for River Pay — use \"Run Safe Test\" to confirm)', 963, NULL, NULL, NULL, '2026-08-27 09:36:17'),
(52, 5, 'fast_api', 'agent_login', NULL, NULL, '{\"agent_username\":\"agent_account\"}', NULL, NULL, 0, 'cURL error 6: Could not resolve host: api.fastprovider.com (see https://curl.se/libcurl/c/libcurl-errors.html) for https://api.fastprovider.com/fast/agent/login', 1748, NULL, NULL, NULL, '2026-08-27 09:36:24'),
(53, 3, 'juwa', 'agent_login', NULL, NULL, '{\"agent_username\":\"109961\"}', '{\"code\":3,\"msg\":\"Invalid token\",\"data\":[],\"count\":0}', 200, 0, 'Invalid token (code 3)', 1515, NULL, NULL, NULL, '2026-08-28 11:43:20'),
(54, 3, 'juwa', 'agent_login', NULL, NULL, '{\"agent_username\":\"109961\"}', '{\"code\":3,\"msg\":\"Invalid token\",\"data\":[],\"count\":0}', 200, 0, 'Invalid token (code 3)', 1041, NULL, NULL, NULL, '2026-08-28 11:50:29'),
(55, 1, 'gameroom777', 'create_player', NULL, 'engmdsahFK', '{\"username\":\"engmdsahFK\",\"nickname\":\"engmdsahFK\"}', '{\"status_code\":200,\"message\":\"Insert successful\",\"data\":{\"id\":3235087,\"account\":\"engmdsahFK\",\"password\":\"[REDACTED]\",\"balance\":\"0\",\"time\":\"2026-09-12 08:35:12\"}}', 200, 1, NULL, 18924, NULL, NULL, NULL, '2026-09-12 07:35:23');

-- --------------------------------------------------------

--
-- Table structure for table `game_api_providers`
--

CREATE TABLE `game_api_providers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `protocol` varchar(255) NOT NULL DEFAULT 'agent_login',
  `display_name` varchar(255) NOT NULL,
  `base_url` varchar(255) NOT NULL,
  `agent_username` varchar(255) NOT NULL,
  `secret_name` varchar(255) DEFAULT NULL COMMENT 'legacy env-var fallback for agent password',
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `automate_create_account` tinyint(1) NOT NULL DEFAULT 0,
  `automate_deposit` tinyint(1) NOT NULL DEFAULT 0,
  `automate_withdraw` tinyint(1) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `request_content_type` varchar(255) NOT NULL DEFAULT 'multipart/form-data',
  `request_method` varchar(255) NOT NULL DEFAULT 'POST',
  `custom_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`custom_headers`)),
  `proxy_url` varchar(255) DEFAULT NULL,
  `requires_ip_whitelist` tinyint(1) NOT NULL DEFAULT 0,
  `health_check_path` varchar(255) NOT NULL DEFAULT '/api/agent/login',
  `whitelist_ip_note` text DEFAULT NULL,
  `docs_url` varchar(255) DEFAULT NULL,
  `last_health_status` varchar(255) DEFAULT NULL,
  `last_health_message` text DEFAULT NULL,
  `last_health_latency_ms` int(11) DEFAULT NULL,
  `last_health_checked_at` timestamp NULL DEFAULT NULL,
  `consecutive_failures` int(11) NOT NULL DEFAULT 0,
  `last_success_at` timestamp NULL DEFAULT NULL,
  `last_failure_at` timestamp NULL DEFAULT NULL,
  `last_error_code` varchar(255) DEFAULT NULL,
  `last_error_summary` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_api_providers`
--

INSERT INTO `game_api_providers` (`id`, `name`, `protocol`, `display_name`, `base_url`, `agent_username`, `secret_name`, `is_active`, `automate_create_account`, `automate_deposit`, `automate_withdraw`, `notes`, `request_content_type`, `request_method`, `custom_headers`, `proxy_url`, `requires_ip_whitelist`, `health_check_path`, `whitelist_ip_note`, `docs_url`, `last_health_status`, `last_health_message`, `last_health_latency_ms`, `last_health_checked_at`, `consecutive_failures`, `last_success_at`, `last_failure_at`, `last_error_code`, `last_error_summary`, `created_at`, `updated_at`) VALUES
(1, 'gameroom777', 'agent_login', 'Game Room 777', 'https://agentserver1.gameroom777.com', 'Teststore22', NULL, 1, 1, 0, 0, NULL, 'multipart/form-data', 'POST', NULL, NULL, 0, '/api/agent/login', NULL, NULL, 'connected', 'Provider is responding normally.', NULL, '2026-08-11 12:24:27', 0, '2026-08-11 12:24:27', NULL, NULL, NULL, '2026-08-10 11:51:32', '2026-08-11 12:24:27'),
(2, 'gamevault999', 'external_signed', 'Game Vault 999', 'https://apius.gamevault999.com', 'Mcashier01', NULL, 1, 1, 0, 0, 'Uses the vendor\'s External API protocol (agent_id + timestamp + secret_key HMAC signing — see API-Documentation.pdf), not the Bearer-login style. agent_username here holds the agent_id. Vendor-provided secret_key: set via GAMEVAULT999_SECRET_KEY in .env or the Providers tab. As of last test, the vendor\'s server returned \'Invalid request parameters\' (code 2) — the agent_id likely needs to be the vendor\'s numeric ID rather than \'Megacashier\'; confirm and update before activating.', 'multipart/form-data', 'POST', '[]', NULL, 0, '/api/agent/login', NULL, NULL, 'unstable', 'Invalid request parameters If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 1090, '2026-08-27 09:35:57', 2, NULL, '2026-08-27 09:35:57', '200', 'Invalid request parameters (code 2)', '2026-08-11 10:34:06', '2026-08-27 09:35:57'),
(3, 'juwa', 'external_signed', 'Juwa', 'https://external.juwa777.com', '109961', NULL, 1, 1, 0, 0, NULL, 'multipart/form-data', 'POST', '[]', NULL, 0, '/api/external/agentBalance', NULL, NULL, 'needs_attention', 'Provider rejected the login token immediately after issuing it (code 3). This is usually a temporary provider-side issue and can be retried; if it keeps happening, confirm this server\'s IP is whitelisted with the provider. If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 1041, '2026-08-28 11:50:29', 3, NULL, '2026-08-28 11:50:29', '200', 'Invalid token (code 3)', '2026-08-18 11:08:26', '2026-08-28 11:50:29'),
(4, 'orion_stars', 'orion_stars_signed', 'Orion Stars', 'https://orionstars.vip:8033', 'Mcashier01', NULL, 1, 1, 0, 0, 'Migrated from Site Settings -> API Keys & Secrets -> Orion Stars Terminal API.', 'multipart/form-data', 'POST', NULL, NULL, 0, '/api/agent/login', NULL, NULL, 'unstable', 'Provider did not respond in time. If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 1455, '2026-08-27 09:36:11', 1, NULL, '2026-08-27 09:36:11', '', 'Orion Stars API error [201]: Session timeout.', '2026-08-18 11:59:23', '2026-08-27 09:36:11'),
(5, 'fast_api', 'fast_api_signed', 'Fast API', 'https://api.fastprovider.com', 'agent_account', NULL, 1, 1, 0, 0, 'Migrated from Site Settings -> API Keys & Secrets -> Fast API Integration. Verify with Test Connection before relying on it, then assign it to the game(s) it should serve.', 'multipart/form-data', 'POST', NULL, NULL, 0, '/api/agent/login', NULL, NULL, 'unstable', 'Provider host could not be resolved. Double-check the base URL. If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 1748, '2026-08-27 09:36:24', 1, NULL, '2026-08-27 09:36:24', '', 'cURL error 6: Could not resolve host: api.fastprovider.com (see https://curl.se/libcurl/c/libcurl-errors.html) for https://api.fastprovider.com/fast/agent/login', '2026-08-18 12:54:39', '2026-08-27 09:36:24'),
(6, 'river_pay', 'river_pay_simple', 'River Pay', 'http://river-pay.com', 'river_login', NULL, 1, 1, 0, 0, 'Migrated from Site Settings -> API Keys & Secrets -> River Pay API. River Pay assigns its own account \"code\" on creation (see RiverPaySimpleProtocol) — verify with Run Safe Test, not just Test Connection, before relying on it.', 'multipart/form-data', 'POST', NULL, NULL, 0, '/api/agent/login', NULL, NULL, 'unstable', 'Provider blocked the request. If the provider requires IP whitelisting, confirm the server IP is approved. If this continues failing, confirm the provider API URL, request format, and whitelist the server IP.', 963, '2026-08-27 09:36:17', 1, NULL, '2026-08-27 09:36:17', '', 'River Pay API request to [balance] failed: 403 <!DOCTYPE html>\n<html lang=\"en\">\n\n<head>\n	<meta charset=\"utf-8\">\n	<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/bootstrap.min.css\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/bootstrap-responsive.min.css\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/bootstrap/css/custom.css?v=1.12\" />\n<link rel=\"stylesheet\" type=\"text/css\" href=\"/lib/datepicker/css/datepicker.css\" />\n<style type=\"text/css\">\n/*<![CDATA[*/\nbody {\r\n	background-image: url(\'/images/bg.png\');\r\n}\r\n		\r\n@media print {\r\n	body { padding: 0; margin: 0; background: none; }\r\n	a:link:after, a:visited:after { content: \"\"; }\r\n	.notforprint { display: none; }\r\n	.forprint { display: block; }\r\n	.for-print { display: block !important; }\r\n}\r\n\r\n@media screen {\r\n	.notforprint { display: block; }\r\n	.forprint { display: none; }\r\n}\n/*]]>*/\n</style>\n<script type=\"text/javascript\" src=\"/assets/f347dd98/jquery.min.js\"></script>\n<script type=\"text/javascript\" src=\"/lib/bootstrap/js/bootstrap.min.js\"></script>\n<script type=\"text/javascript\" src=\"/lib/datepicker/js/bootstrap-datepicker.js\"></script>\n<script type=\"text/javascript\" src=\"/js/shortcut.js\"></script>\n<script type=\"text/javascript\" src=\"/js/main.js?v=1.1.83\"></script>\n<script type=\"text/javascript\" src=\"/js/fp.min.js\"></script>\n<script type=\"text/javascript\" src=\"/js/fp-bootstrap.js\"></script>\n<title>Admin panel</title>\n	<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n	<link rel=\"stylesheet\" href=\"/css/main.css?v=1.094\"/>\n</head>\n\n<body>\n	<div class=\"notforprint\">\r\n		<style type=\"text/css\">\n    body {\n        padding-top: 80px;\n        padding-bottom: 40px;\n    }\n</style>\n<div class=\"row-fluid\">\n	<div class=\"span6 offset3\">\n		<div class=\"alert alert-error\">\n			<h2>Error 403</h2>\n			<p>Access denied.</p>\n		</div>\n	</div>\n</div>\n<div class=\"row-fluid\">\n    <div class=\"span6 offset3\">\n        <a class=\"btn btn-primary\" href=\"/office/logout\"><i class=\"icon icon-white icon-refresh\"></i> Switch account</a>    </div>\n</div>\n	</div>\r\n	<div id=\"forprint\" class=\"forprint\"></div>\r\n<script type=\"module\" src=\"https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925\" integrity=\"sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==\" data-cf-beacon=\'{\"version\":\"2024.11.0\",\"token\":\"69a66274fbdc40c58dd0607c3fc7f8a1\"}\' crossorigin=\"anonymous\"></script>\n</body>\n\n</html>\n (a business error here can be normal for River Pay — use \"Run Safe Test\" to confirm)', '2026-08-18 12:54:39', '2026-08-27 09:36:17');

-- --------------------------------------------------------

--
-- Table structure for table `game_api_provider_secrets`
--

CREATE TABLE `game_api_provider_secrets` (
  `provider_id` bigint(20) UNSIGNED NOT NULL,
  `agent_password` text NOT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_api_provider_secrets`
--

INSERT INTO `game_api_provider_secrets` (`provider_id`, `agent_password`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, 'eyJpdiI6Ino2OVEzV3pSckl6SG9IYUlMeUhKTkE9PSIsInZhbHVlIjoieGgxODBRSlU0ZUZ2c21jZUR4V1I4UT09IiwibWFjIjoiYmNmYTBjNTI4NDE3M2JkYzdlZjFhMjRjMjc2M2M2YWUyMzg5ODNiZDU2ZTA0MTUxNTM0NDg4M2E0MTNiNjBhOSIsInRhZyI6IiJ9', NULL, '2026-08-10 11:53:35', '2026-08-11 12:24:06'),
(2, 'eyJpdiI6Im1yVWJPOGQ2aVBDQk9RT2hQdEY5Qmc9PSIsInZhbHVlIjoiZ3ZEZXBud2lTS1Rqc3dTM1VlRGdtUT09IiwibWFjIjoiZWVkNmIwOWRmMGE1ZTBkMGRmYTgyZTBjMmRmNTM4ODJkZTY4N2QxNWNjZGZhNTEyNjNhODExNTY1NDEyNzk5OSIsInRhZyI6IiJ9', NULL, '2026-08-11 10:34:06', '2026-08-16 11:12:21'),
(3, 'eyJpdiI6ImpPS1lERWlIUXdoUjEzUWxmWENCTmc9PSIsInZhbHVlIjoiaDZXNFVOV2VpZ245YnVJdVhEWE5PS0lubEJFckxLbFBRTFg3Q21UVVhDb3JpZ3B0ais0VTVXRi9nbVBFMFlwZiIsIm1hYyI6IjQxNTY1MGY1MGY2YTkwZjljMWRlNWMyYTk4ODZjMDMxNjUxMWMyMGZlNTU2YmM5ODViYmE4YzAwMDE4ZDdhZGIiLCJ0YWciOiIifQ==', NULL, '2026-08-18 11:08:47', '2026-08-18 11:23:16'),
(4, 'eyJpdiI6IldaaEswOXd4NzhiWlRXcTdvUjk5YWc9PSIsInZhbHVlIjoiN0g2L2Qvay9RTU44aXhrNzJteWhxUT09IiwibWFjIjoiZmE1NDg0MTViOTljMDlkODA1OWQ3ZTYwZGQxMTY3Nzc0MDE4YzM0ODQ1NzZlZjc3Y2E4MDVlYWE3YjY1ZTdjYiIsInRhZyI6IiJ9', NULL, '2026-08-18 11:59:23', '2026-08-18 11:59:23'),
(5, 'eyJpdiI6IkRObWtpMzQwenhYeVlLMVp6dkU4cmc9PSIsInZhbHVlIjoiK2FpZFAxT0xJUlRZV0hJWWUrdVhxQT09IiwibWFjIjoiYjEzYWNjNDM4MjA0ODFiODc5OTYzZDYzM2M4Y2I1OTBhZjNiZjIwNzA1MDA2MjYzMmFmZTUxOTY5MjY5MDEyYiIsInRhZyI6IiJ9', NULL, '2026-08-18 12:54:39', '2026-08-18 12:54:39'),
(6, 'eyJpdiI6IjN6R05CemtnV2ZWejBXWWgzSmZRMEE9PSIsInZhbHVlIjoicG44K3kxZDFRbkZ5Sk45NzRUbzZKdz09IiwibWFjIjoiODczNDc0N2MyMDU1OTc0ZTMxZDQ4MTk4ZTI4MTQ3OGQxOTZmYWRkNDBlODBhMzdjZTNhYWE0YmZjOWNlMmFkYyIsInRhZyI6IiJ9', NULL, '2026-08-18 12:54:39', '2026-08-18 12:54:39');

-- --------------------------------------------------------

--
-- Table structure for table `game_provider_assignments`
--

CREATE TABLE `game_provider_assignments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `game_id` bigint(20) UNSIGNED NOT NULL,
  `provider_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `game_provider_assignments`
--

INSERT INTO `game_provider_assignments` (`id`, `game_id`, `provider_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2026-08-10 11:59:09', '2026-08-10 11:59:09'),
(2, 2, 1, '2026-08-10 11:59:11', '2026-08-10 11:59:11'),
(3, 3, 1, '2026-08-10 11:59:14', '2026-08-10 11:59:14'),
(4, 4, 2, '2026-08-10 11:59:17', '2026-08-11 10:34:06'),
(5, 5, 1, '2026-08-10 11:59:20', '2026-08-10 11:59:20'),
(6, 9, 1, '2026-08-10 12:15:53', '2026-08-10 12:15:53');

-- --------------------------------------------------------

--
-- Table structure for table `game_unlock_requests`
--

CREATE TABLE `game_unlock_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `game_id` bigint(20) UNSIGNED NOT NULL,
  `game_account_id` bigint(20) UNSIGNED DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `game_password` varchar(255) DEFAULT NULL,
  `web_login_url` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admin_note` text DEFAULT NULL,
  `approved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ghl_api_logs`
--

CREATE TABLE `ghl_api_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `provider_reference` varchar(255) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `request_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`request_payload`)),
  `response_payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`response_payload`)),
  `http_status` int(11) DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `error_message` text DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ghl_api_logs`
--

INSERT INTO `ghl_api_logs` (`id`, `user_id`, `provider`, `provider_reference`, `action`, `request_payload`, `response_payload`, `http_status`, `success`, `error_message`, `duration_ms`, `created_at`) VALUES
(1, NULL, NULL, NULL, 'upsert_contact', '{\"locationId\":\"T1QNjGrUssAlvTaHbjiH\",\"firstName\":\"Claude\",\"lastName\":\"Integration Test\",\"name\":\"Claude Integration Test\",\"email\":\"claude-service-test-probe@example.com\",\"phone\":\"+15551234567\",\"source\":\"Horizon Players Room\",\"tags\":[\"site-user-id:522\",\"site-username:claudeservicetestprobe\",\"signup-date:2026-08-27\"]}', '{\"new\":true,\"contact\":{\"id\":\"JAEBbBR56D43gDGLEClJ\",\"dateAdded\":\"2026-08-27T17:32:52.066Z\",\"dateUpdated\":\"2026-08-27T17:32:52.066Z\",\"deleted\":false,\"tags\":[\"site-user-id:522\",\"site-username:claudeservicetestprobe\",\"signup-date:2026-08-27\"],\"type\":\"lead\",\"customFields\":[],\"locationId\":\"T1QNjGrUssAlvTaHbjiH\",\"firstName\":\"Claude\",\"firstNameLowerCase\":\"claude\",\"fullNameLowerCase\":\"claude integration test\",\"lastName\":\"Integration Test\",\"lastNameLowerCase\":\"integration test\",\"email\":\"claude-service-test-probe@example.com\",\"emailLowerCase\":\"claude-service-test-probe@example.com\",\"bounceEmail\":false,\"unsubscribeEmail\":false,\"phone\":\"+15551234567\",\"country\":\"US\",\"source\":\"Horizon Players Room\",\"createdBy\":{\"source\":\"INTEGRATION\",\"channel\":\"OAUTH\",\"sourceId\":\"6a8dc89a488caa8b78df0d68\",\"timestamp\":\"2026-08-27T17:32:52.066Z\"},\"lastUpdatedBy\":{\"source\":\"INTEGRATION\",\"channel\":\"OAUTH\",\"sourceId\":\"6a8dc89a488caa8b78df0d68\",\"timestamp\":\"2026-08-27T17:32:52.066Z\"},\"lastSessionActivityAt\":\"2026-08-27T17:32:52.306Z\",\"validEmail\":null,\"validEmailDate\":null},\"traceId\":\"73337228-d8ea-4d8f-b926-f6fecfc8f0d6\"}', 201, 1, NULL, 4306, '2026-08-27 11:32:53'),
(2, NULL, NULL, NULL, 'update_contact', '{\"locationId\":\"T1QNjGrUssAlvTaHbjiH\",\"firstName\":\"Claude\",\"lastName\":\"Integration Test Updated\",\"name\":\"Claude Integration Test Updated\",\"email\":\"claude-service-test-probe@example.com\",\"phone\":\"+15551234567\",\"source\":\"Horizon Players Room\",\"tags\":[\"site-user-id:522\",\"site-username:claudeservicetestprobe\",\"signup-date:2026-08-27\"]}', '{\"message\":[\"property locationId should not exist\"],\"error\":\"Unprocessable Entity\",\"statusCode\":422,\"traceId\":\"c661c3bc-dd84-4017-b3f3-ea950e901b4a\"}', 422, 0, '[\"property locationId should not exist\"]', 870, '2026-08-27 11:33:06'),
(3, NULL, NULL, NULL, 'update_contact', '{\"firstName\":\"Claude\",\"lastName\":\"Integration Test Updated Again\",\"name\":\"Claude Integration Test Updated Again\",\"email\":\"claude-service-test-probe@example.com\",\"phone\":\"+15551234567\",\"source\":\"Horizon Players Room\",\"tags\":[\"site-user-id:522\",\"site-username:claudeservicetestprobe\",\"signup-date:2026-08-27\"]}', '{\"succeded\":true,\"succeeded\":true,\"contact\":{\"id\":\"JAEBbBR56D43gDGLEClJ\",\"dateAdded\":\"2026-08-27T17:32:52.066Z\",\"dateUpdated\":\"2026-08-27T17:34:16.792Z\",\"tags\":[\"site-user-id:522\",\"site-username:claudeservicetestprobe\",\"signup-date:2026-08-27\"],\"type\":\"lead\",\"locationId\":\"T1QNjGrUssAlvTaHbjiH\",\"firstName\":\"Claude\",\"firstNameLowerCase\":\"claude\",\"fullNameLowerCase\":\"claude integration test updated again\",\"lastName\":\"Integration Test Updated Again\",\"lastNameLowerCase\":\"integration test updated again\",\"email\":\"claude-service-test-probe@example.com\",\"emailLowerCase\":\"claude-service-test-probe@example.com\",\"phone\":\"+15551234567\",\"country\":\"US\",\"source\":\"Horizon Players Room\",\"createdBy\":{\"source\":\"INTEGRATION\",\"channel\":\"OAUTH\",\"sourceId\":\"6a8dc89a488caa8b78df0d68\",\"timestamp\":\"2026-08-27T17:32:52.066Z\"},\"additionalPhones\":[],\"followers\":[],\"customFields\":[],\"additionalEmails\":[]},\"traceId\":\"41d96bb0-823d-4dad-b139-cafda3c5b37b\"}', 200, 1, NULL, 1145, '2026-08-27 11:34:17'),
(4, 126, 'GoHighLevel', '78K4pG7rTlhKTQiaDG5v', 'upsert_contact', '{\"locationId\":\"T1QNjGrUssAlvTaHbjiH\",\"firstName\":\"engmdsah\",\"name\":\"engmdsah\",\"email\":\"eng.md.sahadathossain@gmail.com\",\"source\":\"Horizon Players Room\",\"tags\":[\"site-user-id:126\",\"site-username:engmdsah\",\"signup-date:2026-09-18\"]}', '{\"new\":true,\"contact\":{\"id\":\"78K4pG7rTlhKTQiaDG5v\",\"dateAdded\":\"2026-09-18T14:37:03.176Z\",\"dateUpdated\":\"2026-09-18T14:37:03.176Z\",\"deleted\":false,\"tags\":[\"site-user-id:126\",\"site-username:engmdsah\",\"signup-date:2026-09-18\"],\"type\":\"lead\",\"customFields\":[],\"locationId\":\"T1QNjGrUssAlvTaHbjiH\",\"firstName\":\"engmdsah\",\"firstNameLowerCase\":\"engmdsah\",\"fullNameLowerCase\":\"engmdsah\",\"email\":\"eng.md.sahadathossain@gmail.com\",\"emailLowerCase\":\"eng.md.sahadathossain@gmail.com\",\"bounceEmail\":false,\"unsubscribeEmail\":false,\"country\":\"US\",\"source\":\"Horizon Players Room\",\"createdBy\":{\"source\":\"INTEGRATION\",\"channel\":\"OAUTH\",\"sourceId\":\"6a8dc89a488caa8b78df0d68\",\"timestamp\":\"2026-09-18T14:37:03.176Z\"},\"lastUpdatedBy\":{\"source\":\"INTEGRATION\",\"channel\":\"OAUTH\",\"sourceId\":\"6a8dc89a488caa8b78df0d68\",\"timestamp\":\"2026-09-18T14:37:03.176Z\"},\"lastSessionActivityAt\":\"2026-09-18T14:37:03.450Z\",\"validEmail\":null,\"validEmailDate\":null},\"traceId\":\"f5e5fbb3-c53a-973f-9c38-2bb9614fcaf2\"}', 201, 1, NULL, 1985, '2026-09-18 08:37:09');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `manual_verification_requests`
--

CREATE TABLE `manual_verification_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'phone',
  `contact` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `admin_note` text DEFAULT NULL,
  `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2026_08_01_000002_create_games_table', 1),
(5, '2026_08_01_000003_create_game_accounts_table', 1),
(6, '2026_08_01_000004_create_game_unlock_requests_table', 1),
(7, '2026_08_01_000005_create_payment_gateways_table', 1),
(8, '2026_08_01_000006_create_payment_gateway_accounts_table', 1),
(9, '2026_08_01_000007_create_withdraw_methods_table', 1),
(10, '2026_08_01_000008_create_withdraw_method_fields_table', 1),
(11, '2026_08_01_000009_create_transactions_table', 1),
(12, '2026_08_01_000010_create_transaction_logs_table', 1),
(13, '2026_08_01_000011_create_withdraw_requests_table', 1),
(14, '2026_08_01_000012_create_password_requests_table', 1),
(15, '2026_08_01_000013_create_rewards_config_table', 1),
(16, '2026_08_01_000014_create_reward_history_table', 1),
(17, '2026_08_01_000015_create_notifications_table', 1),
(18, '2026_08_01_000016_create_site_settings_table', 1),
(19, '2026_08_01_000017_create_support_channels_table', 1),
(20, '2026_08_01_000018_create_audit_logs_table', 1),
(21, '2026_08_01_182617_alter_transactions_type_enum_add_transfer', 1),
(22, '2026_08_01_183423_add_proof_url_to_withdraw_requests_table', 1),
(23, '2026_08_02_142009_add_game_account_id_to_game_unlock_requests_table', 2),
(24, '2026_08_02_152832_add_legacy_id_to_users_table', 3),
(25, '2026_08_02_230307_create_otp_verifications_table', 4),
(26, '2026_08_02_170000_add_web_login_url_to_game_tables', 5),
(27, '2026_08_07_000001_create_verification_settings_table', 6),
(28, '2026_08_07_000002_add_api_keys_to_site_settings_table', 7),
(29, '2026_08_07_173016_add_api_provider_to_games_table', 8),
(30, '2026_08_10_230500_create_game_api_providers_table', 9),
(31, '2026_08_10_230501_create_game_api_provider_secrets_table', 9),
(32, '2026_08_10_230502_create_game_provider_assignments_table', 9),
(33, '2026_08_10_230503_create_game_api_logs_table', 9),
(34, '2026_08_11_224200_add_protocol_to_game_api_providers_table', 10),
(35, '2026_08_12_222300_create_backups_table', 11),
(36, '2026_08_12_222301_create_backup_downloads_table', 11),
(37, '2026_08_12_222302_create_recovery_configs_table', 11),
(38, '2026_08_12_232200_create_export_requests_table', 12),
(39, '2026_08_12_233000_add_contact_widget_fields_to_site_settings_table', 13),
(40, '2026_08_13_120000_add_missing_fields_to_verification_settings_table', 14),
(41, '2026_08_13_120100_create_manual_verification_requests_table', 15),
(42, '2026_08_13_130000_create_email_templates_table', 16),
(43, '2026_08_13_140000_add_redeem_limits_to_site_settings_table', 17),
(44, '2026_08_13_150000_add_withdraw_daily_limit_to_site_settings_table', 18),
(45, '2026_08_13_160000_add_gateway_columns_to_transactions_table', 19),
(46, '2026_08_13_170128_add_last_login_at_to_users_table', 20),
(47, '2026_08_27_150234_add_username_suffix_to_games_table', 21),
(48, '2026_08_27_150235_add_provider_account_id_to_game_accounts_table', 21),
(49, '2026_08_27_154752_add_ghl_contact_id_to_users_table', 22),
(50, '2026_08_27_154753_create_ghl_api_logs_table', 22),
(51, '2026_08_27_175307_add_fast_payment_credentials_to_site_settings_table', 23),
(52, '2026_08_27_175308_create_fast_payment_transactions_table', 23),
(53, '2026_08_27_175401_create_fast_payment_api_logs_table', 23),
(54, '2026_08_28_090000_make_action_by_nullable_on_transaction_logs_table', 24),
(55, '2026_08_28_100000_add_instant_recharge_columns_to_transactions_table', 25),
(56, '2026_08_28_110000_add_financial_ledger_columns_to_transactions_table', 26),
(57, '2026_08_28_130000_add_centralized_logging_fields', 27),
(58, '2026_08_29_090000_add_brevo_fields_to_verification_settings_table', 28);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(255) NOT NULL DEFAULT 'info',
  `category` varchar(255) NOT NULL DEFAULT 'general',
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otp_verifications`
--

CREATE TABLE `otp_verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `channel` enum('email','sms') NOT NULL,
  `destination` varchar(255) NOT NULL,
  `code_hash` varchar(255) NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_requests`
--

CREATE TABLE `password_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `game_account_id` bigint(20) UNSIGNED NOT NULL,
  `requested_password` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateways`
--

CREATE TABLE `payment_gateways` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` text NOT NULL DEFAULT '',
  `minimum_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `logo_url` varchar(255) DEFAULT NULL,
  `qr_code_url` varchar(255) DEFAULT NULL,
  `deep_link` varchar(255) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_gateways`
--

INSERT INTO `payment_gateways` (`id`, `name`, `address`, `minimum_amount`, `logo_url`, `qr_code_url`, `deep_link`, `instructions`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'CashApp', 'Please use live chat to deposit', 10.00, '/storage/gateway-qr/xKEJzNHJBtTQSiLiC2BJPkFLGqujm1uPS3c6cRkc.png', NULL, 'cashapp://', 'Cash App Payment Instructions\n\nHow to Pay with Cash App\n- Send us a message on live chat (your right bottom)\n- We will send you working cashapp link, then you can deposit\n- Upload the screenshot, include your tags and send us your username as well.\n\nImportant:\nMake sure the screenshot clearly shows the payment amount and transaction status.', 1, '2026-08-01 12:55:10', '2026-09-17 12:30:05'),
(2, 'Google Pay', 'Message us to get link', 10.00, '/storage/gateway-qr/bgmx1zBRJfrQx2VdPAw5t7R8KSC8PuDaKUjsOt6R.png', NULL, 'https://www.facebook.com/slotsofamericaus', 'Message us to generate link for deposit', 1, '2026-08-01 12:55:11', '2026-09-17 12:32:08'),
(3, 'Chime', '$Lucinda-Cantu-3', 10.00, '/storage/gateway-qr/7koJCrrkbaSxyh11D6GFCOQle1WgStCqWUTT5PFe.jpg', NULL, 'chime://', 'Chime Payment Instructions\nHow to Pay with Chime\n- Send your payment to our Chime username or associated email/phone number.\n- Take a screenshot of the completed transaction confirmation screen within your Chime app.\n- Open the Live Chat / Chatbot, upload the screenshot, and provide your account username or registered email so we can verify and add your funds.\n\nImportant:\n- Ensure the screenshot clearly shows the recipient name, transaction amount, and payment status (Completed/Settled).\n- Please double-check the Chime tag before sending to ensure your funds are sent to the correct account.', 1, '2026-08-01 12:55:11', '2026-09-17 12:31:12'),
(4, 'Paypal', 'kaziagencygroup@gmail.com', 10.00, '/storage/gateway-qr/m1Ahe9Wc5QwOQNI9AO1ax19j5BUP9V6nmY6U9OQI.png', NULL, 'paypal://', 'PayPal Payment Instructions\n\nHow to Pay with PayPal\n- Send your payment to our PayPal email using the Friends & Family option if available.\n- After completing the payment, take a screenshot of the PayPal transaction confirmation.\n- Open the Live Chat / Chatbot, upload the screenshot, and include your account username or registered email so we can verify and credit your balance.\n\nImportant:\nYour balance will be added after our team verifies the payment.', 1, '2026-09-17 12:32:46', '2026-09-17 12:32:46'),
(5, 'USDC', '0x1E287E35F8fD9abc66f913F453979B369ec5926b', 10.00, '/storage/gateway-qr/dVDRZMwRoUMM3LXojRDhqavuTQrldFIPLSBBxJkP.png', '/storage/gateway-qr/hQOafG1y4x8uOuTav9YCvy8KbtfbvNvqOXQ3ta39.jpg', '__chat_support__', 'USDC Payment Instructions\n\nHow to Pay with USDC\n- CHOOSE BASE NETWORK !!!\n- Send the exact amount of USDC to the following wallet address\n- Once the transaction is sent, take a screenshot of the transaction confirmation or TXID.\n- Open the Live Chat / Chatbot, upload the screenshot, and include your account username or email so our team can verify the payment.\n\nImportant:\nUSDC payments may take a few minutes for confirmation on the blockchain.', 1, '2026-09-17 12:33:35', '2026-09-17 12:33:35'),
(6, 'Zelle', 'Adarsh.kazi87@gmail.com', 10.00, '/storage/gateway-qr/mPG36AvdTDgl4646xhswgkkZjrkS4MF1gQRQQsjC.jpg', NULL, 'zelle://', 'Zelle Payment Instructions\n\nHow to Pay with Zelle\n- Send your payment to our Zelle Email.\n- Take a screenshot of the completed transaction confirmation screen within your Zelle app.\n- Open the Live Chat / Chatbot, upload the screenshot, and provide your account username or registered email so we can verify and add your funds.\n\nImportant:\n- Ensure the screenshot clearly shows the recipient name, transaction amount, and payment status (Completed/Settled).\n- Please double-check the Zelle email before sending to ensure your funds are sent to the correct account.', 1, '2026-09-17 12:34:18', '2026-09-17 12:34:18');

-- --------------------------------------------------------

--
-- Table structure for table `payment_gateway_accounts`
--

CREATE TABLE `payment_gateway_accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `gateway_id` bigint(20) UNSIGNED NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `account_number` varchar(255) NOT NULL,
  `priority_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `qr_code_url` varchar(255) DEFAULT NULL,
  `deep_link` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `payment_gateway_accounts`
--

INSERT INTO `payment_gateway_accounts` (`id`, `gateway_id`, `account_name`, `account_number`, `priority_order`, `is_active`, `qr_code_url`, `deep_link`, `created_at`, `updated_at`) VALUES
(1, 1, 'Cash App Official Account', '$HorizonPay', 1, 1, NULL, NULL, '2026-08-01 12:55:11', '2026-08-01 12:55:11'),
(2, 2, 'Zelle Official Account', 'pay@horizon.gg', 1, 1, NULL, NULL, '2026-08-01 12:55:11', '2026-08-01 12:55:11'),
(3, 3, 'Venmo Official Account', '@HorizonPay', 1, 1, NULL, NULL, '2026-08-01 12:55:11', '2026-08-01 12:55:11');

-- --------------------------------------------------------

--
-- Table structure for table `recovery_configs`
--

CREATE TABLE `recovery_configs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_url` varchar(255) DEFAULT NULL,
  `frontend_url` varchar(255) DEFAULT NULL,
  `support_email` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `updated_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recovery_configs`
--

INSERT INTO `recovery_configs` (`id`, `site_url`, `frontend_url`, `support_email`, `notes`, `updated_by`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, NULL, NULL, NULL, '2026-08-12 10:57:23', '2026-08-12 10:57:23');

-- --------------------------------------------------------

--
-- Table structure for table `rewards_config`
--

CREATE TABLE `rewards_config` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` decimal(12,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `rewards_config`
--

INSERT INTO `rewards_config` (`id`, `key`, `value`, `description`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'welcome_bonus', 10.00, 'Free $10 sign up bonus for new players', 0, '2026-08-01 12:55:11', '2026-09-17 12:42:26'),
(2, 'daily_checkin', 5.00, 'Daily $5 free play login reward', 0, '2026-08-01 12:55:11', '2026-09-17 12:42:26'),
(3, 'referral_reward', 15.00, 'Refer a friend and get $15 bonus credit', 0, '2026-08-01 12:55:11', '2026-09-17 12:42:27');

-- --------------------------------------------------------

--
-- Table structure for table `reward_history`
--

CREATE TABLE `reward_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `reward_key` varchar(255) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('wU4pIaFCSDzlRCzaj0Ipcn38DVZQ3zFDWtJh4zSv', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNTh5SGtnSmhhUTNNRzlJamk3RkhyOUE1aUNXQ1JqalNYYWlIcmRadyI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjc6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9sb2dpbiI7czo1OiJyb3V0ZSI7Tjt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1789742278);

-- --------------------------------------------------------

--
-- Table structure for table `site_settings`
--

CREATE TABLE `site_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `site_name` varchar(255) NOT NULL DEFAULT 'Horizon Players',
  `logo_url` varchar(255) DEFAULT NULL,
  `favicon_url` varchar(255) DEFAULT NULL,
  `custom_css` text DEFAULT NULL,
  `colors` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`colors`)),
  `fonts` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fonts`)),
  `nav_links` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`nav_links`)),
  `landing_page_config` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`landing_page_config`)),
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_description` text DEFAULT NULL,
  `seo_keywords` varchar(255) DEFAULT NULL,
  `header_scripts` text DEFAULT NULL,
  `body_scripts` text DEFAULT NULL,
  `footer_scripts` text DEFAULT NULL,
  `whatsapp_number` varchar(255) DEFAULT NULL,
  `telegram_link` varchar(255) DEFAULT NULL,
  `messenger_link` varchar(255) DEFAULT NULL,
  `ghl_api_key` varchar(255) DEFAULT NULL,
  `ghl_location_id` varchar(255) DEFAULT NULL,
  `ghl_assigned_user_id` varchar(255) DEFAULT NULL,
  `ghl_conversation_mode` varchar(255) NOT NULL DEFAULT 'manual',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `game_agent_base_url` varchar(255) DEFAULT NULL,
  `game_agent_id` varchar(255) DEFAULT NULL,
  `game_agent_secret_key` text DEFAULT NULL,
  `orion_stars_base_url` varchar(255) DEFAULT NULL,
  `orion_stars_agent_name` varchar(255) DEFAULT NULL,
  `orion_stars_agent_password` text DEFAULT NULL,
  `fast_api_base_url` varchar(255) DEFAULT NULL,
  `fast_api_app_id` varchar(255) DEFAULT NULL,
  `fast_api_app_secret` text DEFAULT NULL,
  `fast_api_agent_account` varchar(255) DEFAULT NULL,
  `fast_api_agent_password` text DEFAULT NULL,
  `river_pay_base_url` varchar(255) DEFAULT NULL,
  `river_pay_login` varchar(255) DEFAULT NULL,
  `river_pay_password` text DEFAULT NULL,
  `fast_payment_base_url` varchar(255) DEFAULT NULL,
  `fast_payment_merchant_id` varchar(255) DEFAULT NULL,
  `fast_payment_key` text DEFAULT NULL,
  `contact_display_mode` varchar(255) DEFAULT NULL,
  `contact_button_label` varchar(255) DEFAULT NULL,
  `contact_header_title` varchar(255) DEFAULT NULL,
  `contact_widget_position` varchar(255) DEFAULT NULL,
  `contact_button_color` varchar(255) DEFAULT NULL,
  `contact_text_color` varchar(255) DEFAULT NULL,
  `redeem_min_amount` decimal(10,2) DEFAULT NULL,
  `redeem_max_amount` decimal(10,2) DEFAULT NULL,
  `withdraw_daily_limit` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `site_settings`
--

INSERT INTO `site_settings` (`id`, `site_name`, `logo_url`, `favicon_url`, `custom_css`, `colors`, `fonts`, `nav_links`, `landing_page_config`, `seo_title`, `seo_description`, `seo_keywords`, `header_scripts`, `body_scripts`, `footer_scripts`, `whatsapp_number`, `telegram_link`, `messenger_link`, `ghl_api_key`, `ghl_location_id`, `ghl_assigned_user_id`, `ghl_conversation_mode`, `created_at`, `updated_at`, `game_agent_base_url`, `game_agent_id`, `game_agent_secret_key`, `orion_stars_base_url`, `orion_stars_agent_name`, `orion_stars_agent_password`, `fast_api_base_url`, `fast_api_app_id`, `fast_api_app_secret`, `fast_api_agent_account`, `fast_api_agent_password`, `river_pay_base_url`, `river_pay_login`, `river_pay_password`, `fast_payment_base_url`, `fast_payment_merchant_id`, `fast_payment_key`, `contact_display_mode`, `contact_button_label`, `contact_header_title`, `contact_widget_position`, `contact_button_color`, `contact_text_color`, `redeem_min_amount`, `redeem_max_amount`, `withdraw_daily_limit`) VALUES
(1, 'Horizon Players', '/storage/brand-assets/iBjgHeRaagNh4rcMFP6xwyPmGhO8Qqn5AQWVJpax.jpg', '/storage/brand-assets/4e0leJaGU0rJjoipBkh4PQJXKNNwei3o9RGLL3eu.jpg', NULL, '{\"primary\":\"212 100% 65%\",\"secondary\":\"248 100% 71%\",\"background\":\"222 46% 11%\",\"foreground\":\"210 40% 98%\",\"card\":\"217 33% 17%\"}', '{\"primary\":null,\"secondary\":null,\"button\":null}', NULL, '{\"hero\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"badge_text\":\"#1 Trusted Gaming Platform\",\"title_line1\":\"YOUR WINNING\",\"title_highlight\":\"JOURNEY\",\"title_line2\":\"STARTS HERE\",\"subtitle\":\"Sweepstakes, Fish Table, Slots & More - ALL IN ONE PLACE\\nRegister now and start winning today.\",\"trust_items\":[{\"label\":\"Secure & Encrypted\"},{\"label\":\"Fast Approval\"},{\"label\":\"Reliable System\"},{\"label\":\"Instant Cashout - Instant Winnings\"},{\"label\":\"Redeemable Freeplay\"}]},\"stats_banner\":{\"background_type\":\"color\",\"background_color\":\"#0F1729\",\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"stats\":[{\"value\":\"10K+\",\"label\":\"Active Players\"},{\"value\":\"24\\/7\",\"label\":\"Live Support\"},{\"value\":\"$1M+\",\"label\":\"Total Payouts\"},{\"value\":\"50+\",\"label\":\"Games Available\"}]},\"games_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"title\":\"OUR GAMES\",\"subtitle\":\"Discover the best online gaming experience - play top industry games in one place.\\nWhich game you wanna play today?\"},\"transfers_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"badge_text\":\"Lightning Fast\",\"title_line1\":\"INSTANT FUND\",\"title_highlight\":\"TRANSFERS\",\"subtitle\":\"Deposit, Transfer, Redeem or Withdraw your funds instantly. No delays, no hassle \\u2014 your money moves when you want it to.\",\"cta_text\":\"Get Started Free\",\"feature_image_url\":null,\"actions\":[\"Deposit\",\"Withdraw\",\"Transfer\",\"Redeem\"]},\"features_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"title\":\"WHY GAME WITH US?\",\"subtitle\":\"The reasons players trust us\",\"features\":[{\"title\":\"Live 24\\/7 Support\",\"desc\":\"Our dedicated team is always online to solve problems instantly.\",\"image_url\":null},{\"title\":\"Unlimited & Instant Withdrawals\",\"desc\":\"Fast withdrawals to fulfill your needs.\",\"image_url\":null},{\"title\":\"Constant Community Bonuses\",\"desc\":\"Get rewarded with free credits and exclusive promotions.\",\"image_url\":null},{\"title\":\"All Games in One Account\",\"desc\":\"Play all of your favorite games under one account.\",\"image_url\":null}]},\"testimonials_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"title\":\"WHAT PLAYERS SAY\",\"subtitle\":\"Join thousands of satisfied gamers\",\"image_url\":null,\"testimonials\":[{\"name\":\"Alex M.\",\"quote\":\"Best gaming platform I\'ve ever used! Fast payouts and amazing support.\",\"avatar_url\":null},{\"name\":\"Sarah K.\",\"quote\":\"The variety of games is incredible. I play every day!\",\"avatar_url\":null},{\"name\":\"Mike R.\",\"quote\":\"Deposits and withdrawals are instant. Highly recommended!\",\"avatar_url\":null}]},\"faq_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"title\":\"FREQUENTLY ASKED QUESTIONS\",\"subtitle\":\"Everything you need to know before getting started\",\"faqs\":[{\"question\":\"How do I create an account?\",\"answer\":\"Simply click the Register button and fill in your details. It only takes a minute to get started!\"},{\"question\":\"How long do deposits and withdrawals take?\",\"answer\":\"Deposits are instant, and withdrawals are processed within minutes. No long waits!\"},{\"question\":\"Is my personal information secure?\",\"answer\":\"Absolutely. We use industry-standard encryption to protect all your data and transactions.\"},{\"question\":\"Can I play on mobile?\",\"answer\":\"Yes! Our platform works on all devices \\u2014 desktop, tablet, and mobile browsers.\"},{\"question\":\"How do I contact support?\",\"answer\":\"Our 24\\/7 support team is always available. Use the live chat or reach out via email anytime.\"}]},\"cta_section\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"visible\":true,\"pre_title\":\"Don\'t Miss Out\",\"title\":\"REGISTER NOW & START PLAYING YOUR FAVORITE GAMES\",\"button_text\":\"Register Now \\u2014 It\'s Free\",\"image_url\":null},\"footer\":{\"background_type\":\"default\",\"background_color\":null,\"background_gradient\":null,\"background_image_url\":null,\"text_color\":null,\"show_games\":true,\"copyright_text\":\"iGameplayers Copyright @2022\",\"extra_payment_methods\":[{\"name\":\"Chime\",\"logo_url\":\"\\/storage\\/landing-images\\/MMCnvD8PkMyv3211h0zF4J0aKSVNZD8YVykSBIxx.jpg\"},{\"name\":\"Paypal\",\"logo_url\":\"\\/storage\\/landing-images\\/oZgMqXIYQbOwn0mZM2utICZMD0tOJ5IoEEnBe0UP.png\"},{\"name\":\"CashApp\",\"logo_url\":\"\\/storage\\/landing-images\\/qHrCjmtajXyijqShzqizsOno4Clz2hpiDFUVSIL2.png\"},{\"name\":\"USDC\",\"logo_url\":\"\\/storage\\/landing-images\\/IRjPfDzFkifgevfZQ2GTaZRA9ewPtDztlifioS1K.png\"},{\"name\":\"Zelle\",\"logo_url\":\"\\/storage\\/landing-images\\/l3XOoeULHcXmZieKHrO1JOwXMdz4jb0GvWgocP3O.jpg\"}]},\"navbar\":{\"links\":[{\"label\":\"Games\",\"href\":\"#games\"},{\"label\":\"Features\",\"href\":\"#features\"},{\"label\":\"Transfers\",\"href\":\"#transfers\"},{\"label\":\"Frequently Question\",\"href\":\"#faq\"}]}}', 'cloudcasino - #1 Trusted Gaming Platform', 'Sweepstakes, fish games, slots & more — all in one place. Register now and start winning today.', NULL, '<!-- Google Tag Manager -->\n<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({\'gtm.start\':\nnew Date().getTime(),event:\'gtm.js\'});var f=d.getElementsByTagName(s)[0],\nj=d.createElement(s),dl=l!=\'dataLayer\'?\'&l=\'+l:\'\';j.async=true;j.src=\n\'https://www.googletagmanager.com/gtm.js?id=\'+i+dl;f.parentNode.insertBefore(j,f);\n})(window,document,\'script\',\'dataLayer\',\'GTM-59K3WP78\');</script>\n<!-- End Google Tag Manager -->', '<!-- Google Tag Manager (noscript) -->\n<noscript><iframe src=\"https://www.googletagmanager.com/ns.html?id=GTM-59K3WP78\"\nheight=\"0\" width=\"0\" style=\"display:none;visibility:hidden\"></iframe></noscript>\n<!-- End Google Tag Manager (noscript) -->', '<script src=\"https://chat-plugin.pancake.vn/main/auto?page_id=web_casinoclound\"></script>', '+1234567890', 'https://t.me/horizon_support', 'https://m.me/horizon', 'pit-594b52be-213f-456f-a8c6-c7aef2a37ffb', 'T1QNjGrUssAlvTaHbjiH', 'usr_12345', 'manual', '2026-08-01 12:55:11', '2026-09-17 13:10:04', 'https://agent.gameprovider.com', '10045', 'secret_key_12345', 'https://orionstars.vip:8033', 'Mcashier01', 'Fireron2026#$', 'https://api.fastprovider.com', 'app_123456', 'app_secret_123456', 'agent_account', 'agent_password', 'http://river-pay.com', 'river_login', 'river_password', 'https://mh.dollarpaywallet.com', '1092768610', 'c38a302a69b588ea113bc28b31e36ed1', NULL, 'Contact Us', '15551234567', '{\"bottom\":\"20\",\"right\":\"20\"}', '#2d0075', NULL, 40.00, 300.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `support_channels`
--

CREATE TABLE `support_channels` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'message-square',
  `link` varchar(255) NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `support_channels`
--

INSERT INTO `support_channels` (`id`, `name`, `icon`, `link`, `sort_order`, `is_active`, `created_at`, `updated_at`) VALUES
(1, 'Messenger', 'messenger', 'https://m.me/602916016243577', 1, 1, '2026-08-01 12:55:11', '2026-08-12 12:06:01'),
(2, 'Telegram', 'telegram', 'https://t.me/username', 2, 1, '2026-08-01 12:55:11', '2026-08-12 12:05:19'),
(3, 'Whatsapp', 'whatsapp', 'https://wa.me/1234567890', 3, 1, '2026-08-01 12:55:11', '2026-08-12 12:04:40');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `game_id` bigint(20) UNSIGNED DEFAULT NULL,
  `gateway_id` bigint(20) UNSIGNED DEFAULT NULL,
  `gateway_account_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` enum('deposit','withdraw','redeem','transfer','reward') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `deposit_proof_url` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `balance_reserved` tinyint(1) NOT NULL DEFAULT 0,
  `idempotency_key` varchar(255) DEFAULT NULL,
  `provider_reference` varchar(255) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `balance_before` decimal(12,2) DEFAULT NULL,
  `balance_after` decimal(12,2) DEFAULT NULL,
  `failure_reason` text DEFAULT NULL,
  `reviewed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transaction_logs`
--

CREATE TABLE `transaction_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transaction_id` bigint(20) UNSIGNED NOT NULL,
  `action` varchar(255) NOT NULL,
  `action_by` bigint(20) UNSIGNED DEFAULT NULL,
  `old_status` varchar(255) DEFAULT NULL,
  `new_status` varchar(255) DEFAULT NULL,
  `old_amount` decimal(12,2) DEFAULT NULL,
  `new_amount` decimal(12,2) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `action_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `legacy_id` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `avatar_url` varchar(255) DEFAULT NULL,
  `ghl_contact_id` varchar(255) DEFAULT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `role` enum('user','manager','admin') NOT NULL DEFAULT 'user',
  `is_flagged` tinyint(1) NOT NULL DEFAULT 0,
  `flagged_reason` text DEFAULT NULL,
  `flagged_at` timestamp NULL DEFAULT NULL,
  `email_verified_by_admin` tinyint(1) NOT NULL DEFAULT 0,
  `phone_verified` tinyint(1) NOT NULL DEFAULT 0,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `email_notifications` tinyint(1) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `legacy_id`, `name`, `username`, `email`, `phone`, `avatar_url`, `ghl_contact_id`, `balance`, `role`, `is_flagged`, `flagged_reason`, `flagged_at`, `email_verified_by_admin`, `phone_verified`, `phone_verified_at`, `country`, `state`, `gender`, `date_of_birth`, `email_notifications`, `email_verified_at`, `last_login_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'fa7e88cd-46d6-4b1b-bf24-3c3b17f857b3', 'gamepaneluser027', 'gamepaneluser027', 'arjance091184@gmail.coma', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$zWYtuptl61gp4j0G16Im.eOCr8MLkRTNtRHfD7kHyXRgS0FHnJnsW', NULL, '2026-03-29 00:12:46', '2026-03-29 00:12:46'),
(2, '206a8f8a-871a-4122-b097-24bf92c17a5e', 'orange69', 'orange69', 'kerriaorange824@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$GaIP72sWpq1p45IRBhiJc.26ipU2PUNZcvk1dK2s9dNrWZyRWhTxO', NULL, '2026-04-09 07:31:34', '2026-04-09 07:31:34'),
(3, '3b42ba1a-0106-4d87-869c-c3dbdc4313e5', 'Daniel Forero', 'gamepaneluser021', 'fpdaniel98@hotmail.com', NULL, NULL, NULL, 0.00, 'manager', 0, NULL, NULL, 0, 1, '2026-03-19 06:39:57', 'United States', 'Texas', 'Male', '1998-07-19', 1, '2026-03-19 06:39:57', NULL, '$2a$10$HcGw1XC960A.9pQzfWL70.hLNKd9cVjeNpInbvQxF3fIjZz4Gt8Ie', NULL, '2026-03-19 06:39:57', '2026-03-19 06:39:57'),
(4, '13398bf5-9aee-484e-b1b7-9a6834e20960', 'Bonnie Mccarthy', 'gamepaneluser020', 'mccarthybonnie3647@outlook.com', '(432) 341-8555', NULL, NULL, 0.00, 'manager', 0, NULL, NULL, 0, 1, '2026-03-18 10:36:23', 'United States', 'Colorado', 'Male', '1990-10-10', 1, '2026-03-18 10:36:23', NULL, '$2a$10$a2HSojSNZ3JxfPF6FcOHRem9jYd8ISFdxZI8EWLXfGeflhqYUTAs2', NULL, '2026-03-18 10:36:23', '2026-03-18 10:36:23'),
(5, '5236f4b9-4297-443f-8356-1afd6b5042a2', '417sFinest', '417sFinest', 'trentonsuncle2023@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$dtTid1o74pz3kO5ISC3TTuTbYoI.vzQsjhgUnSjjkNYleqLfEcaXa', NULL, '2026-04-13 00:05:53', '2026-04-13 00:05:53'),
(6, 'fa7730f4-af96-425f-8be0-6ad158459823', 'gamepaneluser019', 'gamepaneluser019', 'tesiornajerome@gmail.com', NULL, NULL, NULL, 0.00, 'manager', 0, NULL, NULL, 0, 1, '2026-03-18 10:26:30', NULL, NULL, NULL, NULL, 1, '2026-03-18 10:26:30', NULL, '$2a$10$m.3ybYRndS4LqAspFFe9guh8GDMJXqi/tQ1G6GYGyaNs27ZY5evPu', NULL, '2026-03-18 10:26:30', '2026-03-18 10:26:30'),
(7, '9cc2e658-68f6-4b69-88a4-7a88de5c9714', 'gamepaneluser3', 'gamepaneluser003', 'johny.freelancer1802@gmail.com', NULL, NULL, NULL, 9920.00, 'admin', 0, NULL, NULL, 0, 1, '2026-03-16 07:52:44', NULL, NULL, NULL, NULL, 1, '2026-03-16 07:52:44', NULL, '$2a$10$.M7R0AdPyxZSKmpgzYlxbuzfoWAJpES3uyD4nBBGN4a9wn97OxauC', NULL, '2026-03-16 07:52:44', '2026-03-16 07:52:44'),
(8, '1a828f14-b7e6-4e76-95eb-83a35881638d', 'manager', 'manager', 'devhridoysaha@gmail.com', NULL, NULL, NULL, 0.00, 'manager', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$7F/xTv6YLIyeXXeZdFEWOOYYU2YFqLyLmAOUFRlztKUR.QAiNNpNy', NULL, '2026-03-14 14:17:18', '2026-03-14 14:17:18'),
(9, '2d8dbcb2-43c1-40f7-aaac-71a233855392', 'gamepaneluser002', 'gamepaneluser002', 'prodtest_final@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$AX13hQxKBPnn83u.1xVMRedrC3HnoV..F6Fro.iHo30Vkns1qcWMC', NULL, '2026-03-15 14:50:41', '2026-03-15 14:50:41'),
(10, 'b79eef8e-8da4-4d9c-9fdb-b4d3d72a7021', 'gamepaneluser011', 'gamepaneluser011', 'stressuser1@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$cCq/xnFr9x6bIwf8SYDnieo8tz5OcIPLOgNfF9Aw3R1N9zZF7Vo9W', NULL, '2026-03-16 08:05:04', '2026-03-16 08:05:04'),
(11, '55b471aa-b1bd-4d14-9c08-6fcb869b4b1f', 'gamepaneluser012', 'gamepaneluser012', 'stressuser3@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$7aj1n2/D/sZ2xMI.QgfpAuEMoesVYPDGWWaHvKTyrqjfi5lsy11Kq', NULL, '2026-03-16 08:05:06', '2026-03-16 08:05:06'),
(12, '7a79a400-1c83-4484-9634-38e4f2b3e919', 'gamepaneluser013', 'gamepaneluser013', 'stressuser2@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$V.PdCenoHYsYQgoKYIGoEuRD.4RoP7pRLF0UD1FKdFmUDzWPFzU6O', NULL, '2026-03-16 08:05:06', '2026-03-16 08:05:06'),
(13, '45bda384-0d70-476f-9543-b4202c3ab92e', 'gamepaneluser014', 'gamepaneluser014', 'stressuser4@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$99HV9Dd8zQQBNN1wEGl5EuZLCN/L7yUv37sb4TMgUIFfWw3nx.W/y', NULL, '2026-03-16 08:05:06', '2026-03-16 08:05:06'),
(14, '7eb4f2e8-121b-4eb1-b706-66ac4432e096', 'gamepaneluser015', 'gamepaneluser015', 'stressuser5@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$4FjwbeeWou9ucXwqETqQ/u2ifYkJXnGsleAFt1zAiChx9S5t3p9sm', NULL, '2026-03-16 08:05:07', '2026-03-16 08:05:07'),
(15, 'e3ca1221-faf3-4ae6-af62-8f21724fe599', 'gamepaneluser016', 'gamepaneluser016', 'journeytest2026@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-03-16 08:09:42', NULL, '$2a$10$P90gvgpf/ryZ57fCpc3CO.8mcL/ylJSMhQbNyMheuyijayrklE/Ry', NULL, '2026-03-16 08:09:42', '2026-03-16 08:09:42'),
(16, '3b9ba802-3a77-49bf-a36e-b4a264373433', 'gamepaneluser017', 'gamepaneluser017', 'validation_final@example.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$FgVhQOcTo45Z3IVhdcJsE.b0iBkF4PleB67ouPqk3aTPn70GpwFcW', NULL, '2026-03-16 08:16:21', '2026-03-16 08:16:21'),
(17, '3f1fdc57-ccd7-4746-833b-8243eef13625', 'keantest', 'gamepaneluser022', 'keanalbion@gmail.com', NULL, NULL, NULL, 0.00, 'manager', 0, NULL, NULL, 0, 1, '2026-03-19 20:22:48', 'United States', NULL, NULL, NULL, 1, '2026-03-19 20:22:48', NULL, '$2a$10$OI5T9f1xcOQWamv0GsXtX.Uwilg9b.rX4mDezEXcH.3LFJSNk5hHC', NULL, '2026-03-19 20:22:48', '2026-03-19 20:22:48'),
(18, 'd4fed0e8-dea1-46f0-9b27-0b0c7ca3f003', 'gamepaneluser024', 'gamepaneluser024', 'idorevargassss45@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$0cEfa.oUAy2D2qVc6ha08uNQ8Pr4mPmksHbpDVgMy6blwXkUaVyOC', NULL, '2026-03-28 23:19:01', '2026-03-28 23:19:01'),
(19, '19bd44fd-d30f-47a4-b2fd-7244683d705e', 'Zonaman74', 'Zonaman74', 'lilfizzle77@gmail.com', '+13242000418', NULL, NULL, 1.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-10 08:31:06', NULL, '$2a$10$ff0TzQ.c3PKqOdiIEjqVR.c5FhvLtIa.3WUC8Sam869QcP0XSapWC', NULL, '2026-04-10 08:31:06', '2026-04-10 08:31:06'),
(20, '22983e66-bc83-471f-b78d-c340be4eac6c', 'Manager001', 'gamepaneluser010', 'developer@kaziagency.com', '(849) 532-1568', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/22983e66-bc83-471f-b78d-c340be4eac6c/avatar.png?t=1774620204913', NULL, 6222.00, 'admin', 0, NULL, NULL, 0, 1, '2026-03-16 08:03:33', 'United States', NULL, NULL, NULL, 1, '2026-03-16 08:03:33', NULL, '$2a$10$Y4MhrYTDroVypuKptPnuSuBBrI9dAsJ6NhnJapv1NGr43Yyii1z.O', NULL, '2026-03-16 08:03:33', '2026-03-16 08:03:33'),
(21, 'e93608b6-0ef3-41cd-9bff-21273747c8e5', 'Jovany Martinez', 'gamepaneluser025', 'jaygetslit14@gmail.com', '+19156919585', NULL, NULL, 2.00, 'user', 0, NULL, NULL, 0, 1, '2026-03-28 23:43:42', 'United States', 'Texas', 'Male', '1996-11-19', 1, '2026-03-28 23:43:42', NULL, '$2a$10$Cv3iMM7sE20nyfqBko36tuaaRhyX2LZSCkSYeVmUfWk.WGv3iUy26', NULL, '2026-03-28 23:43:42', '2026-03-28 23:43:42'),
(22, 'eaf0243e-a6ef-4217-9605-796fd03dcd65', 'gamepaneluser018', 'gamepaneluser018', 'sfxyn2528@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-03-17 11:30:14', NULL, NULL, NULL, NULL, 1, '2026-03-17 11:30:14', NULL, '$2a$10$MTHl1dQHipCl9orbtvkMOeyNhq1mBk79lFoNZVuQ.GOY9r8oITggO', NULL, '2026-03-17 11:30:14', '2026-03-17 11:30:14'),
(23, 'bf10de0c-4cd1-401a-a525-a340e8558860', 'gamepaneluser023', 'gamepaneluser023', 'jkazi8482@gmail.com', '+13464383077', NULL, NULL, 2.00, 'admin', 0, NULL, NULL, 0, 1, '2026-03-23 19:52:45', NULL, NULL, NULL, NULL, 1, '2026-03-23 19:52:45', NULL, '$2a$10$VzwOf1B1cxL0oUbkuNTA6.r4k7E5i/h/eruvam8EVM2kYZADI1ixG', NULL, '2026-03-23 19:52:45', '2026-03-23 19:52:45'),
(24, '2a6fc89d-e5f8-4973-bc06-02b6c6a14215', 'Dc1985', 'Dc1985', 'deaz.nuts.0416@gmail.com', '+13525380769', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-26 20:57:25', NULL, '$2a$10$N/SDemkK5U2gwnpeJ.0Qy.er7pS7A1yE2TeCMiqWF0/5ZQu1aX0oG', NULL, '2026-04-26 20:57:25', '2026-04-26 20:57:25'),
(25, '0d3a7453-3a2f-44ec-ac37-ae14db5faead', 'hridooysaha', 'hridooysaha', 'hridooysaha@gmail.com', '+15551234567', NULL, NULL, 829.00, 'admin', 0, NULL, NULL, 0, 1, '2026-03-09 07:56:12', 'United States', NULL, NULL, NULL, 1, '2026-03-09 07:56:12', NULL, '$2a$10$0Vxpx5YSBY7foBeY1.axZuRclwWR/cyk9x28X/3QAHTMzTIhPGaVK', NULL, '2026-03-09 07:56:12', '2026-03-09 07:56:12'),
(26, 'dac2342a-2c2d-4932-a203-41b0ba14339f', 'Minh Nguyen', 'gamepaneluser031', 'minty98108@gmail.com', '+12065322187', NULL, NULL, 1.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Washington', 'Male', '1989-05-30', 1, '2026-04-03 14:46:37', NULL, '$2a$10$psjiw6i1Xc2LrsMVeKGI1e3CiMnJkcOQBT/q/yymMphN87/VqLUI6', NULL, '2026-04-03 14:46:37', '2026-04-03 14:46:37'),
(27, '116e06c7-d837-4e94-96e4-adeda965dd91', 'ahmed nasher', 'mooo86', 'anasher2007@gmail.com', '+14158106302', NULL, NULL, 1.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'California', 'Male', '1986-07-02', 1, '2026-04-10 20:09:43', NULL, '$2a$10$/srSXFv1e5/XpbZ.TBCJuOncs9u3oiq8FNYBGTWHyRNTPHHVF6Gcy', NULL, '2026-04-10 20:09:43', '2026-04-10 20:09:43'),
(28, '0b205287-6b29-4109-aff8-3b96a8b37050', 'Angelina Vigil', 'Angelina5a', 'angevig303@gmail.com', '+17203823049', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/0b205287-6b29-4109-aff8-3b96a8b37050/avatar.jpg?t=1776147601993', NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-04-14 00:08:28', 'United States', 'Colorado', 'Female', '1986-12-14', 1, '2026-04-14 00:08:28', NULL, '$2a$10$odcZf/cZn9gGViInjUNrU.GI3FXLlBLwPdUKUilgGd4rHLpPgZGxy', NULL, '2026-04-14 00:08:28', '2026-04-14 00:08:28'),
(29, '20b6c02d-7733-4fd1-adea-3a0a274127af', 'Sihibon42', 'Sihibon42', 'sihibon42@gmail.com', '+12543143958', NULL, NULL, 1.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-13 17:45:36', NULL, '$2a$10$1YEn3Htpb9ZaeDLPYMyNnurVRMdlmoVGKq.6/8cDU8txQwcdO1Zrq', NULL, '2026-04-13 17:45:36', '2026-04-13 17:45:36'),
(30, 'c65a5b64-460e-47ca-87b3-22a45e9bbc48', 'Jermaine Penamante', 'Kpeamante', 'kpeamante@gmail.com', '(575) 562-5556', NULL, NULL, 1.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '2026-12-03', 1, '2026-04-05 11:34:27', NULL, '$2a$10$qEcbs6daoPqQuoWPqosb0OdUQS.EWlvhACBSt9hsCKa3bK9PiWDGe', NULL, '2026-04-05 11:34:27', '2026-04-05 11:34:27'),
(31, '2e361ee0-8d12-40b7-96a9-2b44ad25bae2', 'Cheryn Cornelio', 'gamepaneluser029', 'cheencornelio888@gmail.com', '(575) 562-5556', NULL, NULL, 1.00, 'manager', 0, NULL, NULL, 0, 1, '2026-04-02 11:38:45', 'United States', 'California', 'Female', '1988-08-08', 1, '2026-04-02 11:38:45', NULL, '$2a$10$YPTVVJZ5uhP4iQ3iFM//W.nTcN.iOJJnIg9Y6gwF2aCHzNwJvwkCK', NULL, '2026-04-02 11:38:45', '2026-04-02 11:38:45'),
(32, '67a85b81-9b94-446a-937a-28994c0152d4', 'Jermaine Peñamante', 'gamepaneluser028', 'rebanoj@gmail.com', '(575) 562-5556', NULL, NULL, 1.00, 'manager', 0, NULL, NULL, 0, 1, '2026-04-02 11:38:27', 'United States', 'Texas', 'Female', '2000-12-03', 1, '2026-04-02 11:38:27', NULL, '$2a$10$mAAFpBhzkxnPYucGszT5uuoc1AJ3iiyyC7SF86nxOI8VYtoiYhy1W', NULL, '2026-04-02 11:38:27', '2026-04-02 11:38:27'),
(33, '9e547987-a4f5-4018-8580-d81ca19f2f25', 'Pedleylina', 'Pedleylina', 'pedleylinda59@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$0oL1rt1zNnoWQ8PvrvwnLu7VUqWlj.x.Tv6vVyK4877saxnOQ4K7y', NULL, '2026-04-14 12:49:19', '2026-04-14 12:49:19'),
(34, '7a23e8dd-06d5-487a-8c98-5a9f213cd773', 'Down2Burn', 'Down2Burn', 'xdtbxlotx@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$jXFmt/H/vQZ1aL2WPcJ0COeFfJkN1pk/TZdUpbUNfoC2z4Prh7xdy', NULL, '2026-04-16 03:48:38', '2026-04-16 03:48:38'),
(35, '191142b9-8f21-4e46-baeb-4fa698de2171', 'contacthri', 'contacthri', 'contact.hridayshaha@gmail.com', NULL, NULL, NULL, 900.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-04 06:59:51', NULL, '$2a$10$z6KOHRaLz2n/e3SN0EdaZeN/Eyb9UPvdENQ0z7Dze1NP5OQTHU9we', NULL, '2026-04-04 06:59:51', '2026-04-04 06:59:51'),
(36, 'c4bbb679-7643-4297-b409-e84326232975', 'Chinotru', 'Chinotru', 'giltru123@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$pN5duGP3bwC/2aZBFKw3Y.srJF3SOjR2cipuSkNWIYUSBj2wxSs42', NULL, '2026-04-16 04:11:33', '2026-04-16 04:11:33'),
(37, 'e9848bfa-df38-4fb4-827c-bd4d1bf2fb96', 'Lenny1331', 'Lenny1331', 'loriann2481@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$KaiT.DdchHEjnxoZcazqCup34o2Bmm2sN/H94oUOvZuIBoS79kDL.', NULL, '2026-04-16 07:29:59', '2026-04-16 07:29:59'),
(38, '5dd0429e-67d2-45ff-80f9-37f122eeb8ef', 'calderona', 'calderona', 'calderonandreya8@gmail.com', '+13252341062', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-04-29 23:45:09', NULL, '$2a$10$qO3zuvNoSAkmAqdjTmQTN.y1bpjVgJ7B2hYp89zRLYVrqKvm/6ymC', NULL, '2026-04-29 23:45:09', '2026-04-29 23:45:09'),
(39, 'f4906e7b-aabb-4830-a745-8cc21cbf6fdc', 'Lindakay', 'Lindakay', 'lin.dodd1970@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$6vUnXP3COl4G5Ne0975tAO5fcneY2ZLaQBS//Zs4fZrRXWiFsylt6', NULL, '2026-05-06 18:45:01', '2026-05-06 18:45:01'),
(40, '0b8e1d11-adb7-4fc0-83fc-d01616d4665a', 'Captaink', 'Captaink', 'kurtallen.martinez@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$woQ9aOAYmK1BsV.meek1nunZgtoZp5iH4X8dSMDEbdYq3zOtYwVvC', NULL, '2026-05-02 00:13:06', '2026-05-02 00:13:06'),
(41, '5a43e668-6f0d-4d1d-aae6-a52bebf36002', 'NikeBitch', 'NikeBitch', 'rochanicolerr1989@gmail.com', '+12104192841', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-02 14:47:30', NULL, '$2a$10$JacWHNj2r/6FihV/DffMMOOWYtlzU98iiJwBxvgM/dUy5xskvful2', NULL, '2026-05-02 14:47:30', '2026-05-02 14:47:30'),
(42, '770e15aa-edbd-4cef-896f-b7ca20ef6552', 'RONI50', 'RONI50', 'veronicadougherty10@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$4od8rYv6BK7q5atAvSvJievQqVmuFyqBJA2g45DxReOfyE8H2eIQS', NULL, '2026-05-11 07:00:17', '2026-05-11 07:00:17'),
(43, '51c3bb63-d6ad-4626-84ea-048c993a3192', 'Tara121', 'Tara121', 'taracamille121@gmail.com', '+16156841261', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-11 07:50:47', NULL, NULL, NULL, NULL, 1, '2026-05-11 07:50:47', NULL, '$2a$10$glcDActB25LujC5fTa3Qm.NZNU8KW0J4Z1L4Q9fnQyTv/8mvWbY1m', NULL, '2026-05-11 07:50:47', '2026-05-11 07:50:47'),
(44, '338b71dd-011f-41cd-a7dc-c22984d36e56', 'Candace Daigneault', 'gamepaneluser026', 'shorti_006@yahoo.com', '17755608646', NULL, NULL, 2.00, 'user', 0, NULL, NULL, 0, 1, '2026-03-29 00:06:17', 'United States', 'Nevada', 'Female', '1988-07-06', 1, '2026-03-29 00:06:17', NULL, '$2a$10$7xYs60hYRrmu2H8Vtid3QOA8F8CG2j.2B4mRS651XEo/vB592gAZO', NULL, '2026-03-29 00:06:17', '2026-03-29 00:06:17'),
(45, 'fe72a975-0346-47e2-848c-d9030cf5e38f', 'e46cnett', 'e46cnett', 'e46cnet@gmail.com', '+13613980526', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-11 09:34:38', NULL, NULL, NULL, NULL, 1, '2026-05-11 09:34:38', NULL, '$2a$10$Yjgb0Ip0SPpTEXCYr5Zzk.Tni.mTr4RBkov3fss22HhMxHNmdM1.a', NULL, '2026-05-11 09:34:38', '2026-05-11 09:34:38'),
(46, '080b9dfc-b331-4ed5-99fe-3964123c0816', 'Charles197', 'Charles197', 'charleswilhoit@gmail.com', '+17043209695', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-11 10:12:58', NULL, '$2a$10$4yeMEgTLldc8f8n.ZrHU1.sG1LkUFTHSKny7omkS0kZwCOQP.r3M6', NULL, '2026-05-11 10:12:58', '2026-05-11 10:12:58'),
(47, '8a3a746d-6b09-4375-876a-e738ff7c3cf6', 'Lequan Graham', 'BlaQ910', 'losquan910@gmail.com', '+19102067691', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/8a3a746d-6b09-4375-876a-e738ff7c3cf6/avatar.jpg?t=1778519626669', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Male', '1990-07-01', 1, '2026-05-11 08:54:07', NULL, '$2a$10$kkg5qZgPTAFYmeCwallfa.pkwifa3YWju.lR1BvPoTK1E2uLptySi', NULL, '2026-05-11 08:54:07', '2026-05-11 08:54:07'),
(48, '058119c9-1623-4dca-915f-c5f4eca8503d', 'Snowman6', 'Snowman6', 'thesnowman139@gmail.com', '+14092499953', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-29 23:25:33', NULL, '$2a$10$i6htXM.krzADRCegyOSvWOg.Kw.LN1K7yazr2Kcgegt7gevllporm', NULL, '2026-05-29 23:25:33', '2026-05-29 23:25:33'),
(49, '1df9c3d1-3a46-4b76-a033-bd860468e6af', 'Ness22', 'Ness22', 'vanessayarbrough@gmail.com', '+12137968989', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-21 04:17:17', NULL, NULL, NULL, NULL, 1, '2026-05-21 04:17:17', NULL, '$2a$10$ewhB8N6HL1luATW1Mao68OD/etm2Q20SRetrl7KpOZsxUhODT9cUS', NULL, '2026-05-21 04:17:17', '2026-05-21 04:17:17'),
(50, '42176f9a-a393-4ab2-ad37-73e9fb42c41b', 'Prettibaew', 'Prettibaew', 'prettibaewhitfield@gmail.com', '+19042350548', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-11 11:17:51', NULL, '$2a$10$07IstzMDo97g5zMRDnd2seHprTGi78c/vloiabvpwuVg4gYK1SWUm', NULL, '2026-05-11 11:17:51', '2026-05-11 11:17:51'),
(51, 'b2a163b1-d778-45c1-a9c4-3c961d1c3e22', 'Rayluvbj', 'Rayluvbj', 'rayluvbj@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$A.fwD.GmAPY1J1PYC7vI8eTtiJCwWxCRiy11LcXLPhFDebsm5ZTpi', NULL, '2026-05-21 13:43:34', '2026-05-21 13:43:34'),
(52, 'd6032e18-a4a2-4ef0-8332-98ca25e80a6b', 'Dbarrera86', 'Dbarrera86', 'requenesdiana33@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$SNxD5ssayHazZ/AHGmOc4ulus8GWjBJM5blOt9hb9LBR0Z2/1nReu', NULL, '2026-05-22 13:36:10', '2026-05-22 13:36:10'),
(53, '250b6c93-c087-4ab5-9e4a-217b5b6d7cab', 'Angelita Estrada', 'Bigang', 'bigang343@gmail.com', '+19282464146', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Arizona', 'Female', '1989-05-22', 1, '2026-06-03 02:01:31', NULL, '$2a$10$wZY9WPljj4mU4bZJhJ8UTOSEXhs8LNxhTJ2RJTr61lZfejk0JTAou', NULL, '2026-06-03 02:01:31', '2026-06-03 02:01:31'),
(54, '469f5384-69ba-4c7e-b38c-1d88c574bcd9', 'Cellus06', 'Cellus06', 'marcellusnelson0@gmail.com', '19046243587', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-11 12:22:49', NULL, NULL, NULL, NULL, 1, '2026-05-11 12:22:49', NULL, '$2a$10$qxaoPjw5M8MoixKPYW8g5eY7tL1VBffW2iZ6fsSZhCr8RqrNIGh4.', NULL, '2026-05-11 12:22:49', '2026-05-11 12:22:49'),
(55, '571fca0a-c23a-400e-91fc-147e097e60d9', 'Angie7561', 'Angie7561', 'mylife75611940@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$CDRSvDhBh9tKWfp2bJZ91uXImuJEfu2FNFEodQl/SV8RZGK2tKJ9i', NULL, '2026-05-11 13:13:45', '2026-05-11 13:13:45'),
(56, 'e14dcfb1-4f34-4b7a-9514-eb83cda921e6', 'asherann20', 'asherann20', 'asherann20@gmail.com', '+19037063255', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-30 09:48:39', NULL, '$2a$10$x7KPMAysCZ0f3KBmU1Q2d.rQ8Hjq/zxhBhNwXIj2HUS..HwxI7E2S', NULL, '2026-05-30 09:48:39', '2026-05-30 09:48:39'),
(57, 'cc9c66dc-e772-4c55-b786-766a501d8b32', 'Moneytrees', 'Moneytrees', 'shell702ink@gmail.com', '+16027480479', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-11 18:13:27', NULL, '$2a$10$IRblAPPwMZz0a.nKpOVGq.ZvEX/mXmbxNlGd4SEIITdEPyCfHwwDS', NULL, '2026-05-11 18:13:27', '2026-05-11 18:13:27'),
(58, '438889e6-e835-426d-9f1d-9389c5b6b513', 'Luckydiva', 'Luckydiva', 'sanderseva513@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-11 21:45:45', NULL, '$2a$10$0NdfpCMDqyPKIMvi8fOQHuOSfFln.O0bMBEfGKyAGi0EY/bN4R7vu', NULL, '2026-05-11 21:45:45', '2026-05-11 21:45:45'),
(59, '29e94178-84e5-4ae8-a445-129205fd5317', 'Renotta921', 'Renotta921', 'renottasmith3@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$i21u1eTej.kXYjGLpeGYueu3Rg8H9w4v2aoVUzB9wHhHrtxaELxuu', NULL, '2026-05-25 16:01:29', '2026-05-25 16:01:29'),
(60, '33ec3708-65d9-42a3-ad66-97485ede2b3a', 'Thomas1968', 'Thomas1968', 'joearlene1991@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$zjB0Boq6bJbxhWtB8uHZYOz79OMH5XNVAoyN7lJtDJj4.8WAzhwXi', NULL, '2026-06-03 02:07:12', '2026-06-03 02:07:12'),
(61, 'a430d7e6-a31f-4d7c-bea4-bd979a3e7039', 'Bannon Roe', 'Broe1588', 'roebannon198@gmail.com', '+13253519471', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-11 22:44:54', 'United States', 'Texas', 'Male', '1988-11-10', 1, '2026-05-11 22:44:54', NULL, '$2a$10$w0t1j4nGOZfBE3CTpu4seO857CiAwhYRJ.txIaxr1wsjBn/xmKXYe', NULL, '2026-05-11 22:44:54', '2026-05-11 22:44:54'),
(62, '92857f2a-c195-40f5-a314-5fd19cdfb8d1', 'GANGGANG', 'GANGGANG', 'kenwuanmoore888@gmail.com', '+16626250752', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-31 01:58:05', NULL, '$2a$10$ME34pBYjmTQukvMOmdnEcOhP/3184xRAgyzVNyhaTOOWyoHcw.kza', NULL, '2026-05-31 01:58:05', '2026-05-31 01:58:05'),
(63, 'dc413b7d-8923-43b0-a7bd-0d2170b466e6', 'Carriejane', 'Carriejane', 'amadorcarrie5@gmail.com', '+19106271980', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$abhlU1cRscfCjr5SBSaGcuc4WOBTTBKp/Om/BQ8lUqODx0KxaEwCi', NULL, '2026-05-12 01:39:35', '2026-05-12 01:39:35'),
(64, 'bd9fa8c0-857b-4440-883a-2d2af6c347b6', 'DomAlva86', 'DomAlva86', 'bigstixbambino1986@icloud.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$OOTymq0OFlpYgkEXVdO2FuiKVkB5TbKfZDCaTGksNYWPhiHlFY91.', NULL, '2026-05-12 17:34:31', '2026-05-12 17:34:31'),
(65, '440360ab-8835-470d-a81a-2d92f408c04f', 'Cro5554gr', 'Cro5554gr', 'shelley3rd@yahoo.com', '+12563461141', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-12 19:54:01', NULL, NULL, NULL, NULL, 1, '2026-05-12 19:54:01', NULL, '$2a$10$SsLSYV3dtKH7e5zgvTuere898PwFBYTySTtHx6EugsFWaZhaIa8ce', NULL, '2026-05-12 19:54:01', '2026-05-12 19:54:01'),
(66, '19419cbc-be1c-4797-aeac-585113ed1a74', 'bigsav', 'bigsav', 'llrsav123@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$Sa8z0ZkogU3smbppGdvHaeSbo8cY.ZN8L9/wtb3Pk.1aUkZY1YXRm', NULL, '2026-05-13 12:48:35', '2026-05-13 12:48:35'),
(67, '29657779-955a-4376-8bc3-c0321d361006', 'Sandra haney', 'sandicandi', 'nomorebarking71@gmail.com', '+18283710354', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/29657779-955a-4376-8bc3-c0321d361006/avatar.jpg?t=1779775427801', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Female', '1971-11-11', 1, '2026-05-25 23:55:55', NULL, '$2a$10$EpzNryWN/EB5XuClGzjByOg1oIwk9Cd.nPEhtEY77TKqZczA0I/pe', NULL, '2026-05-25 23:55:55', '2026-05-25 23:55:55'),
(68, '3f31edd8-8e86-496a-b235-d0de04fc05b7', 'Anthony Hartsell', 'UHolyT0k3r', '86gthartsell@gmail.com', '(828) 460-4055', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Male', '1985-12-04', 1, NULL, NULL, '$2a$10$D21CF4FjuFIU54fqclCY.OEKtjWbplLEMrWS5M5pLfA1HxB0YXHLm', NULL, '2026-05-13 23:14:21', '2026-05-13 23:14:21'),
(69, 'b84df363-4da6-4bbd-b8f7-5867f1f3db1d', 'Momogismo1', 'Momogismo1', 'henrikhuefken@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$hma/AAf1l/RIELe4u2opTeh6dkTtkkvNdQ9U9kl4aJroCXQ90mkmG', NULL, '2026-05-28 09:41:26', '2026-05-28 09:41:26'),
(70, '453d5a84-fcbd-4ed5-8b1b-72c6f607ff4d', 'Angela Cox', 'Accox48', 'malayjdavis@gmail.com', '+18063025121', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/453d5a84-fcbd-4ed5-8b1b-72c6f607ff4d/avatar.jpg?t=1780277612541', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', NULL, '1978-03-28', 1, '2026-05-31 19:28:59', NULL, '$2a$10$2sM1hX2fx7.FJCmHA9F0NO1eJQmzed2nlONiYxWibSIf67pPx3Epu', NULL, '2026-05-31 19:28:59', '2026-05-31 19:28:59'),
(71, '5d284537-07b0-48c4-b31c-d1e4da62691b', 'Flatland23', 'Flatland23', 'dominicalvarado1986@gmail.com', '+12102887102', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-16 11:40:01', NULL, '$2a$10$eMOeh4VFJiGwDK3EIDkGv.aJpe8F7zdjuzU0q2XmvDalYtXkar/du', NULL, '2026-05-16 11:40:01', '2026-05-16 11:40:01'),
(72, '7d167b3c-9f14-479a-9d19-e85da15f93a5', 'brianferg', 'brianferg', 'brian.ferguson1208@gmail.com', '+14794320989', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-28 15:17:52', NULL, '$2a$10$Of.R7c88P0JCuPYG4lel7.AFeQv.fxNhSVuSuSuAhu8KlDGYJCaPe', NULL, '2026-05-28 15:17:52', '2026-05-28 15:17:52'),
(73, 'af72d76a-a52f-4cde-b451-e9f321176f9d', 'Sserggane', 'Sserggane', 'sserg9281@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$wLSNIghQNOc.aXwFkMWzNOA88RfynTMtfDl9J05IikyAvl64EB07m', NULL, '2026-05-28 21:29:06', '2026-05-28 21:29:06'),
(74, 'dba776ca-0d77-430c-9809-d4ad76d3f72c', 'DalyaW', 'DalyaW', 'whitedalya2@gmail.com', '+19039904106', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$WxcEiSv2Ryrtg1bI0/BFluhyt9SEmLYvjgv2nXOjTh0zhqpUu9ZYa', NULL, '2026-05-29 14:58:01', '2026-05-29 14:58:01'),
(75, '257157af-be20-41f7-be56-ca63e4e9400b', 'Aries6648', 'Aries6648', 'ariesaquariusflames@gmail.com', '+19183167508', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-31 15:36:43', NULL, '$2a$10$Eprr8bFtxItHcgMcHzFvZuq/.U6ey3CY1JkFwvat1W6SpZjC0cose', NULL, '2026-05-31 15:36:43', '2026-05-31 15:36:43'),
(76, 'f085d523-27f4-4f30-928f-73dddd48e10e', 'JennStarz', 'JennStarz', 'jenstar2024@icloud.com', '+19288674125', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-29 18:31:43', NULL, '$2a$10$fR6XsZkgfbG0YgL47Som3.W8Syq1xbm2m4qwrJ6Rmcg8Jnd/4FNkK', NULL, '2026-05-29 18:31:43', '2026-05-29 18:31:43'),
(77, 'c997cac7-d47f-45b8-b72a-63e89bac12d4', 'sNiksNak69', 'sNiksNak69', 'malindaelrod69@gmail.com', '+17402597141', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-31 19:55:23', NULL, '$2a$10$Q//pSzS8Jut7PgQxXV7riejdS7XYj3xt8fVopZpgL3Y6Pn8fowDbm', NULL, '2026-05-31 19:55:23', '2026-05-31 19:55:23'),
(78, 'a8c1489b-ba79-44ba-ae77-3b6b79eeba76', 'Bosshogg18', 'Bosshogg18', 'dreaprtr@gmail.com', '+19542662550', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-05-31 19:22:10', NULL, '$2a$10$gso4JuiAtVGh1NGtCsB2.ONgE.f.RZrK06BqDe76WW9SF5O2M1iA6', NULL, '2026-05-31 19:22:10', '2026-05-31 19:22:10'),
(79, '3b71b67d-1b16-4455-8727-aab8b723546e', 'Emilio Villa', 'Villa96', 'emilio.villa122376@gmail.com', '(719) 396-8574', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/3b71b67d-1b16-4455-8727-aab8b723546e/avatar.jpg?t=1780720776049', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Colorado', 'Male', '1976-12-23', 1, '2026-06-05 22:31:30', NULL, '$2a$10$3trfaZ0IqUgmtr6mXoGmWu/3YxXJ0uuji6Tx/zSyBKLHMYxpa93SG', NULL, '2026-06-05 22:31:30', '2026-06-05 22:31:30'),
(80, 'e0a5209d-02a4-4bff-b04a-ee5f2508f415', 'Kelly Lopez', 'Berry327', 'kellyberry948@gmail.com', '12543140552', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 1, '2026-05-24 17:49:31', 'United States', 'Texas', 'Female', '1973-03-27', 1, '2026-05-24 17:49:31', NULL, '$2a$10$SqxMaMhQ714MoH1195.ZG.Mn0JXM7Kmz.M93o2s5xTDcvJB7jTloC', NULL, '2026-05-24 17:49:31', '2026-05-24 17:49:31'),
(81, '274e5348-0cfb-4563-82ef-44dd868ea121', 'Ashante', 'Ashante', 'ashantebryant50@gmail.com', '+13189906518', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-05 16:10:45', NULL, '$2a$10$2FF7r5yowujfq0MdYqutP.Zl.yJ3/JxN0cjRSTzmp7VgoMC0uuEGu', NULL, '2026-06-05 16:10:45', '2026-06-05 16:10:45'),
(82, 'cadab019-97ce-4086-84ab-fc574c6f2b21', 'Cotty Pointer', 'TheCtheild', 'cottypointer44@gmail.com', '+16623855913', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Mississippi', 'Male', '1982-10-09', 1, '2026-06-04 03:40:52', NULL, '$2a$10$FP.A1orrxcoMuD4W0eJkd.r.JAYpWHh78BCfZVjYFeaY8IX9YlaxC', NULL, '2026-06-04 03:40:52', '2026-06-04 03:40:52'),
(83, '12f5fa23-6173-474c-9c3b-aa48e9971dc8', 'Alicia', 'Alicia', 'reteoretep9@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$pYN8TBv3AIY1ufu7wlUfeOe9OmHckSrtO7ESdra4HR6f4q1ZVtsyG', NULL, '2026-06-06 00:17:58', '2026-06-06 00:17:58'),
(84, '1e66a512-332f-47e2-a903-b80daa4afabc', 'Tony666', 'Tony666', 'ttony123p@gmail.com', '+14085697185', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-05 22:50:56', NULL, '$2a$10$3f.4FO5tloeftyWywMgKqO0CsLqG8fr5kKhkJPQv8dkwMNjU.QiTu', NULL, '2026-06-05 22:50:56', '2026-06-05 22:50:56'),
(85, '45cab222-0433-437c-9eff-cf00a26fb7cf', 'Ledet2026', 'Ledet2026', 'huttoamber92@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$eA/MEIJ5L3sLhQvOLPUlPOMPZnt10xiiha8YRlM1KIMxgf0OvDquK', NULL, '2026-06-06 00:56:52', '2026-06-06 00:56:52'),
(86, '627db00b-7665-48cd-9d7a-1c04b116d51d', 'Tinkerb12', 'Tinkerb12', 'thrashbrandi0113@gmail.com', '1-769-344-4762', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-07 00:41:38', NULL, '$2a$10$V7q1TFCgrVJ2hbOt/7ZEa.a5hfACCq1kUMhcl0EgbmAyhSUBoMb7C', NULL, '2026-06-07 00:41:38', '2026-06-07 00:41:38'),
(87, '77a18e4a-be19-4918-8fa7-ec56f4a03310', 'Akfire27', 'Akfire27', 'akfirecracker1082@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$aESGuFi6lT9g0wY9wTWVGenTUW5UFq6HETXgLrK.i1h229p8E7LXm', NULL, '2026-06-07 07:43:27', '2026-06-07 07:43:27'),
(88, '17cad623-1847-4fd6-9d16-5e82df793c28', 'brentmaia8', 'brentmaia8', 'brentmaia@gmail.com', '13183068046', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-07 07:38:45', NULL, '$2a$10$SWCLnZ8LPTxqhqHQXz5Eu..lJ8B3gcw4FtlbuVXZXqqaYVCY.Xs/2', NULL, '2026-06-07 07:38:45', '2026-06-07 07:38:45'),
(89, 'd6874bf6-a99f-4f64-b2b8-924e94605db3', 'Leah2218', 'Leah2218', 'littlekitty8188@gmail.com', '+14233158640', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-07 14:28:46', NULL, '$2a$10$Z3VDJd.xm/t4tQdDPN6KJuUuuWyTIn/bEVH.6giJOx7VyTBklf2Cu', NULL, '2026-06-07 14:28:46', '2026-06-07 14:28:46'),
(90, '8bfb4c2c-61e0-49c5-84c1-fb3c756d80f2', 'Becky Bailey', 'bec42081gm', 'bec42081@gmail.com', '+12548424100', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1981-10-14', 1, '2026-06-18 16:04:13', NULL, '$2a$10$HWhvQe3i3YzjOsHYO4cWU.FXYjBpHbKLXuArKM/O5aeWFdo7w8pii', NULL, '2026-06-18 16:04:13', '2026-06-18 16:04:13'),
(91, '4d0a0e47-a809-4bbc-a756-908cbb3d84e4', 'Jazzy9981', 'Jazzy9981', 'cegusjazz6969@gmail.com', '+19034909588', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-07 18:52:28', NULL, '$2a$10$Ull.OlL6IHtFr9nhctyQW.YAW6RhAtjXGV4a6eCI4xIdKoSrTRUhW', NULL, '2026-06-07 18:52:28', '2026-06-07 18:52:28'),
(92, '95fae210-d3be-4a7c-b65d-a02b4b48b21a', 'andi44', 'andi44', 'andriadean23@gmail.com', '+19046137876', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-08 17:50:37', NULL, '$2a$10$adjaCv20ZnUpsB9w4cbAAOHiTEiFQ7aPGX4IA14mTJ8V4ltdSqbHi', NULL, '2026-06-08 17:50:37', '2026-06-08 17:50:37'),
(93, '3b24bc83-86bc-4abc-967a-18a9e5d65b20', 'Spivey84', 'Spivey84', 'patrickspivey174@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-09 00:34:20', NULL, '$2a$10$tIxBMpSct.PYU8n0U8cyeO0T0CRDufmL4E2vgG.w2POr26ZYzrTD.', NULL, '2026-06-09 00:34:20', '2026-06-09 00:34:20'),
(94, '675a1dff-91cd-4a8a-856a-96c58f083917', 'Gamerslots', 'Gamerslots', 'gamerslots@myyahoo.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$VRnuEQ5geqIy1sVadSs/BuwSrux4NFfwEO0zW67FtXVbbeFPw6shO', NULL, '2026-06-09 05:44:33', '2026-06-09 05:44:33'),
(95, 'e03a43a4-8f97-49c6-97fd-637f55db81a6', 'aidynr72', 'aidynr72', 'ashlybeers4@gmail.com', '+18164078535', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-07-26 06:47:18', NULL, '$2a$10$vI5xg0geYygpPAnsxz/t8uCmJb6p2tg0cQFTVGxd9EfzlknPLDQGu', NULL, '2026-07-26 06:47:18', '2026-07-26 06:47:18'),
(96, '4b08110c-9fc3-47e3-a27d-1c876f4603fa', 'Swdk2230', 'Swdk2230', 'whytho2300@proton.me', '+12704017358', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-19 14:58:49', NULL, '$2a$10$7X6WGm82mJ0m57Qwy5EaOetX74jB./P3AhjigWImgWiOmBkT9xTL.', NULL, '2026-06-19 14:58:49', '2026-06-19 14:58:49'),
(97, 'ad12b88a-5f4b-4293-a012-c3dfbecc4c57', 'Angela Cox', 'Moneiigang', 'acox5096@gmail.com', '+18064458156', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/ad12b88a-5f4b-4293-a012-c3dfbecc4c57/avatar.jpg?t=1781010404277', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1978-03-28', 1, '2026-06-09 07:02:24', NULL, '$2a$10$YCFUZzgEAV0ZaJHsNJ1lreRQ7oopUB/a/1NcmQS25ViAcXCfdsA3a', NULL, '2026-06-09 07:02:24', '2026-06-09 07:02:24'),
(98, 'e437382f-9d5c-4191-bc51-f66dd50740ce', 'Jdb777', 'Jdb777', 'desecratethroughreverence767@gmail.com', '+16015229235', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-20 08:36:16', NULL, '$2a$10$NyQZsIFgYuI9Z5TKp2mFdupaOXq/S5CJX9oWg4Hc/9hR77fM9f8lO', NULL, '2026-06-20 08:36:16', '2026-06-20 08:36:16'),
(99, 'a79146d5-1224-4806-b895-d4e1a8216eed', 'Stefanie Medina', 'MedinaLokz', 'lapinchilokamedina2020@gmail.com', '+19093238653', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'California', 'Female', '2000-09-18', 1, '2026-06-10 00:55:57', NULL, '$2a$10$lA75CXe7Zr.PC.WcMEM4w.49L/tPmMSch.OUqt6VZRTu5GroQ6IHO', NULL, '2026-06-10 00:55:57', '2026-06-10 00:55:57'),
(100, 'bdb7ead4-f38b-4865-9b92-08da9bc0f95c', 'Jesterdago', 'Jesterdago', 'sgathvampire@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$VVxlS7CbXIVO6/E3KZrqLuFTQRLJa01q.o6C0VUxTetSrJ3ir0TDO', NULL, '2026-06-10 09:18:25', '2026-06-10 09:18:25'),
(101, '690d0ea2-8330-4a62-95af-b988121dc048', 'Kidcole', 'Kidcole', 'alyssagess46@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-07-26 12:18:27', NULL, '$2a$10$9ANSQoxTpTwX5RwxIev4heZjx5h2DTmmKIRJ5Rx885bIi/u1tSIYG', NULL, '2026-07-26 12:18:27', '2026-07-26 12:18:27'),
(102, '96a613fd-464b-4191-a940-2a7f8390ef4c', 'Asstrother', 'Asstrother', 'allison.strother@outlook.com', '+19363062294', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-10 10:42:33', NULL, '$2a$10$olT/xnYaofFYy/OSjerBi.LZRnzfIfnEcwl/MNpDSMzzqF3sUTUZ2', NULL, '2026-06-10 10:42:33', '2026-06-10 10:42:33'),
(103, 'e0a96e37-70fd-415e-9ee7-25a0d3467ce4', 'Treybutts1', 'Treybutts1', 'buttschristopher9@gmail.com', '+12562245562', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$2o6iNuIEv9ZcI5qWYoLb/OFznDP8xvfg0CeYanl8T.R/b9B/ZDTAW', NULL, '2026-06-11 13:10:57', '2026-06-11 13:10:57'),
(104, 'cdaef630-9e10-4cd2-b423-522888dbcbe2', 'MoonWalker', 'MoonWalker', 'scarleo556@gmail.com', '+1 228-344-4257', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-11 14:19:45', NULL, '$2a$10$TaZDLayUMmh1IugZ2.oVTOZYi9K3.hmpFABZFagDxKtsVYoi54joK', NULL, '2026-06-11 14:19:45', '2026-06-11 14:19:45'),
(105, '174fc845-8272-4460-88ac-1299561823be', 'peachboy', 'peachboy', 'peac.h.v.i.tal@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$ozlcs/TtsWFetxZttm1Eze9X6gu7UZ/ZmZrhdh8woBu.MY6z5.zrK', NULL, '2026-06-13 12:13:05', '2026-06-13 12:13:05'),
(106, '1d6c14cd-e216-4807-b88a-9a9767e92879', 'Twicetheg', 'Twicetheg', 'cleangigi2019@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$wKd5ogfVuHQ8dYa7GHzC5u81PX9HqjDgppPs0D7ZpAZFUwHh7nfuy', NULL, '2026-06-15 18:41:45', '2026-06-15 18:41:45'),
(107, 'b176fee0-5589-4c3b-9e32-98f272273c05', 'Victor Garcia', 'Vtxx432', 'vicgarcia727372@gmail.com', '+14322145783', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/b176fee0-5589-4c3b-9e32-98f272273c05/avatar.jpeg?t=1787800589698', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1994-09-04', 1, '2026-08-26 06:19:24', NULL, '$2a$10$NLM5nvOatUtPlO0mPCzHa.caS3lx50TRzUeqBU8jqYRHbeqRMkTY.', NULL, '2026-08-26 06:19:24', '2026-08-26 06:19:24'),
(108, '80fa1c27-f080-483b-b56d-797f171e8a96', 'Chamizo142', 'Chamizo142', 'allanchamizo405@gmail.com', '+16189229589', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-08-04 23:24:17', NULL, '$2a$10$AdrSFr0tUyhKZEQfVvoyEuiUWxV3N/BNiAPh6iLAu1rjCsbvRzzLa', NULL, '2026-08-04 23:24:17', '2026-08-04 23:24:17'),
(109, 'd0de54e3-23bf-46b8-9365-cf1a6ee12980', 'Krystal Fuller', 'Sexiroxi87', 'dimepieceroxi@gmail.com', '+19366153866', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/d0de54e3-23bf-46b8-9365-cf1a6ee12980/avatar.jpg?t=1782276848898', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1987-08-03', 1, '2026-06-23 22:48:58', NULL, '$2a$10$plm603W9G2Z5PH7zcG9QHegTfGyw9Eh1qTWTXqmXOTmoV5CCTHUdW', NULL, '2026-06-23 22:48:58', '2026-06-23 22:48:58'),
(110, '99ebcad4-c61d-4875-8d05-1c5ce05b257f', 'Philip Andrews', 'Zaddyb75', 'stutterstep75@outlook.com', '+19843748340', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/99ebcad4-c61d-4875-8d05-1c5ce05b257f/avatar.jpg?t=1781753044594', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'North Carolina', 'Male', '1975-03-06', 1, '2026-06-17 05:28:29', NULL, '$2a$10$zYXO/L20bEAb1WvAngZVIegNAKe7.87oJrmYqQGhZoHQioFfv6eo.', NULL, '2026-06-17 05:28:29', '2026-06-17 05:28:29'),
(111, '17603ad3-2d9e-4c5b-bf0e-4b7a7dccab67', 'Eyjey22', 'Eyjey22', 'ajagustin3@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$3Q3tSnmShrA3DRsZdmAU1.GSK0pgqDLDgxhNpvT3GQ.RrkpWmG.wS', NULL, '2026-06-18 02:37:03', '2026-06-18 02:37:03'),
(112, '75dfed2b-8bfb-4387-8d88-c590f5299053', 'RaeRod66', 'RaeRod66', 'luvmy.wifesara04@gmail.com', '+16822035203', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-18 07:25:03', NULL, '$2a$10$Ie.bkDlMWoWJOc6IysKoLOm2HC7TDZVUlwBj0gDb9M8upyOkPPQ5q', NULL, '2026-06-18 07:25:03', '2026-06-18 07:25:03'),
(113, '5481cc3d-40ae-45c8-9e09-bed12ac5db23', 'Cellus0606', 'Cellus0606', 'nelsonalreginald@gmail.com', '19046243587', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-26 08:24:26', NULL, '$2a$10$54k7z1ZoiOruNxtCSB1YU.qa7WwoHidrUDLlO4OyJilsejPgcstke', NULL, '2026-06-26 08:24:26', '2026-06-26 08:24:26'),
(114, 'ddc3a756-a3c4-4bf8-9f4c-0e9c4518fa2b', 'Vanessa Dykes', 'Nessa4444', 'detachedloyal1@gmail.com', '+15155142182', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/ddc3a756-a3c4-4bf8-9f4c-0e9c4518fa2b/avatar.png?t=1782755851172', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Iowa', 'Female', '1988-02-13', 1, '2026-06-02 12:09:32', NULL, '$2a$10$a9H74EXKeyWy791y/bDlsuTxj9SEDIZN3Br1xHsl5mngrFZAcCeUe', NULL, '2026-06-02 12:09:32', '2026-06-02 12:09:32'),
(115, 'da3d28fa-6212-4b45-a879-9a1b07587029', 'Willy562', 'Willy562', 'williamescotooo@yahoo.com', '+15623884370', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-08-08 08:25:18', NULL, '$2a$10$.PFjlqUQAjf5DnslODFD9OBp8sGddmBlf3D.I4bhLaFviBp/e9ctu', NULL, '2026-08-08 08:25:18', '2026-08-08 08:25:18'),
(116, 'a016dcc5-541b-4fcd-aa2c-dcda1ff27f29', 'Kelly Lopez', 'KBerry', 'kmlop32773@gmail.com', '+12543140552', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Female', '1973-03-27', 1, NULL, NULL, '$2a$10$gz9Y6OO0KYOCWjcgImLCSeSQjOwvXI3y/jy2cmgUFfztUJ6K5dPWy', NULL, '2026-07-01 14:04:09', '2026-07-01 14:04:09'),
(117, 'e838a347-9902-49d3-b56b-50aac90e7141', 'Beans666', 'Beans666', 'bengeeman12715@gmail.com', '+13614605638', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-06-16 13:26:26', NULL, '$2a$10$kJsD3lsQFgrlGz6I0k59UOiABhd3Vgfoj3Pr.C0jD6QWqx98lBq/e', NULL, '2026-06-16 13:26:26', '2026-06-16 13:26:26'),
(118, '3227127b-8bd9-40a3-860f-0a75e7372d67', '0928ldm', '0928ldm', 'lmcdav70@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$y2nhdMq46H/p9L7ZDFIuIOicayiZUgix5/w8DBaDgBXW5z7nZNkO.', NULL, '2026-07-13 07:32:13', '2026-07-13 07:32:13'),
(119, '804c63ed-dfb1-4920-93ed-468a738f7a4c', 'Kenlucky83', 'Kenlucky83', 'kendraleewhitledge@gmail.com', '+12709528571', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$bZGqG3fUwig5BaJJwO6Bg.K821EIqmo/f6/M0mItjzkNv3.sYZeDu', NULL, '2026-07-16 06:21:19', '2026-07-16 06:21:19'),
(120, '45a9efad-2a33-4706-87f7-cca6dadf3379', 'Cheyannah1', 'Cheyannah1', 'cheyannahg2024@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$hP.C9PCMrSyAxIM7KpDaFuqY2MYtUAHUeGcfFRS.pSj5Y69XmKXpW', NULL, '2026-07-17 02:11:24', '2026-07-17 02:11:24'),
(121, '4b6e4fba-12d0-4625-82ba-1bf3ee3233fb', 'Mark Mineo', 'Meekus', 'meekus0714@gmail.com', '+15127123297', 'https://bezokxmtizliawrvctwa.supabase.co/storage/v1/object/public/avatars/4b6e4fba-12d0-4625-82ba-1bf3ee3233fb/avatar.jpg?t=1788345396074', NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1986-09-19', 1, '2026-05-31 06:07:13', NULL, '$2a$10$Mlyy4HEs0pw.Q0zsYhmSO.wLe1htMScEXK5hl3v0sbwnHJpKNScz6', NULL, '2026-05-31 06:07:13', '2026-05-31 06:07:13'),
(122, '80a9224a-492d-4857-9635-23bdfa1c4a0b', 'Cheriholt', 'Cheriholt', 'cn8618721@gmail.com', '+17693461655', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-08-29 10:12:36', NULL, '$2a$10$LeUOyJQmyFE/.Sxpvdhi4.lTE1CLmcaeADGEKwhlCviN2IqjjG4OW', NULL, '2026-08-29 10:12:36', '2026-08-29 10:12:36'),
(123, 'bd36baf8-b126-4523-8147-c61032cde055', 'Nunes2025', 'Nunes2025', 'livinglongandluckyin2025@gmail.com', '+19125539235', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, '2026-08-12 01:25:21', NULL, '$2a$10$RUrf9aVp2qXV0Uj9x5Q9kuHbSYEWQMvAh9SKCiYXVpkt3Ic6efr6O', NULL, '2026-08-12 01:25:21', '2026-08-12 01:25:21'),
(124, 'ec6ea6f2-53ce-491d-a7cd-2f3dddda13e0', 'jackylyn24', 'jackylyn24', 'jackylyn2429@gmail.com', NULL, NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, '$2a$10$se1RL5EUC9FOIWBGCJkIqe9xNq33HZLIjqP9tvdCfHWq6t77EmUbC', NULL, '2026-09-13 22:54:51', '2026-09-13 22:54:51'),
(125, 'cc9b273e-5676-4c9f-bf96-191eb8d765b8', 'Mark Mineo', 'Meekus777', 'mmineo512@gmail.com', '15127123297', NULL, NULL, 0.00, 'user', 0, NULL, NULL, 0, 0, NULL, 'United States', 'Texas', 'Male', '1986-09-19', 1, '2026-09-02 04:14:28', NULL, '$2a$10$d0BPRZCKiFRjn6iDzI9px.WVAVVRpPzZ1erbOeuEdnHOh/azfSVOa', NULL, '2026-09-02 04:14:28', '2026-09-02 04:14:28'),
(126, NULL, 'engmdsah', 'engmdsah', 'eng.md.sahadathossain@gmail.com', NULL, NULL, '78K4pG7rTlhKTQiaDG5v', 0.00, 'admin', 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2026-09-18 08:38:03', '$2y$12$l4ipp81D9pVECpAt8JtD3OOtpF7qQq4OU3jNC435Qpwg4avENRJ9a', NULL, '2026-09-18 08:37:07', '2026-09-18 08:38:03');

-- --------------------------------------------------------

--
-- Table structure for table `verification_settings`
--

CREATE TABLE `verification_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email_verification_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `phone_verification_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `otp_expiry_minutes` int(10) UNSIGNED NOT NULL DEFAULT 5,
  `resend_cooldown_seconds` int(10) UNSIGNED NOT NULL DEFAULT 60,
  `max_attempts` int(10) UNSIGNED NOT NULL DEFAULT 5,
  `max_per_hour` int(10) UNSIGNED DEFAULT NULL,
  `smtp_host` varchar(255) DEFAULT NULL,
  `smtp_port` int(10) UNSIGNED DEFAULT 587,
  `smtp_username` varchar(255) DEFAULT NULL,
  `smtp_password` varchar(255) DEFAULT NULL,
  `smtp_encryption` varchar(255) DEFAULT 'tls',
  `mail_from_address` varchar(255) DEFAULT NULL,
  `mail_from_name` varchar(255) DEFAULT 'Horizon Players',
  `infobip_base_url` varchar(255) DEFAULT NULL,
  `infobip_api_key` text DEFAULT NULL,
  `infobip_sms_sender` varchar(255) DEFAULT 'Horizon',
  `infobip_whatsapp_sender` varchar(255) DEFAULT NULL,
  `infobip_email_sender` varchar(255) DEFAULT NULL,
  `infobip_sms_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `infobip_whatsapp_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `infobip_email_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `brevo_api_key` text DEFAULT NULL,
  `brevo_sms_sender` varchar(255) DEFAULT NULL,
  `brevo_sms_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `brevo_email_sender` varchar(255) DEFAULT NULL,
  `brevo_email_sender_name` varchar(255) DEFAULT NULL,
  `brevo_email_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `preferred_phone_channel` varchar(20) NOT NULL DEFAULT 'sms_only',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `verification_settings`
--

INSERT INTO `verification_settings` (`id`, `email_verification_enabled`, `phone_verification_enabled`, `otp_expiry_minutes`, `resend_cooldown_seconds`, `max_attempts`, `max_per_hour`, `smtp_host`, `smtp_port`, `smtp_username`, `smtp_password`, `smtp_encryption`, `mail_from_address`, `mail_from_name`, `infobip_base_url`, `infobip_api_key`, `infobip_sms_sender`, `infobip_whatsapp_sender`, `infobip_email_sender`, `infobip_sms_enabled`, `infobip_whatsapp_enabled`, `infobip_email_enabled`, `brevo_api_key`, `brevo_sms_sender`, `brevo_sms_enabled`, `brevo_email_sender`, `brevo_email_sender_name`, `brevo_email_enabled`, `preferred_phone_channel`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 5, 60, 5, NULL, NULL, 587, NULL, NULL, 'tls', NULL, 'Horizon Players', 'nd2vdj.api.infobip.com', '2e414403e7b4d8d0fbfc79d83cafd8bf-bee7f9d7-aa68-4f10-9bf5-1b1912e0f04d', 'ServiceSMS', '447860088970', NULL, 1, 0, 0, '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', 'Horizon', 1, 'developer@kaziagency.com', NULL, 1, 'sms_only', '2026-08-07 10:52:41', '2026-09-14 07:09:58');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_methods`
--

CREATE TABLE `withdraw_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `minimum_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `maximum_amount` decimal(12,2) NOT NULL DEFAULT 10000.00,
  `fee_percentage` decimal(5,2) NOT NULL DEFAULT 0.00,
  `fee_fixed` decimal(12,2) NOT NULL DEFAULT 0.00,
  `processing_time` varchar(255) NOT NULL DEFAULT 'Instant',
  `instructions` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `withdraw_methods`
--

INSERT INTO `withdraw_methods` (`id`, `name`, `code`, `logo_url`, `minimum_amount`, `maximum_amount`, `fee_percentage`, `fee_fixed`, `processing_time`, `instructions`, `is_active`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 'CashApp', 'cashapp', '/storage/brand-assets/Y2qnAgTP8x3VqwpN415bjT4kH2GUDLDDV5geKUQu.png', 100.00, 100.00, 0.00, 0.00, 'Instant - 15 mins', NULL, 1, 1, '2026-08-01 12:55:11', '2026-09-17 12:35:00'),
(2, 'Chime', 'zelle', '/storage/brand-assets/WO9zXX7nI9D8HUt2itix00JX0G3rxlIbf3ahYULT.jpg', 40.00, 100.00, 0.00, 0.00, '10 - 30 mins', NULL, 1, 2, '2026-08-01 12:55:11', '2026-09-17 12:35:35'),
(3, 'USDC', 'venmo', '/storage/brand-assets/iVd8VzQjLV4D57hsI4hXYMr05TdiIUDeSiHYBqnK.png', 40.00, 100.00, 0.00, 0.00, '10 - 30 mins', NULL, 1, 3, '2026-08-01 12:55:11', '2026-09-17 12:36:09'),
(4, 'Zelle', 'zelle_2', '/storage/brand-assets/vClUBLWwOrgRU8BUtTz2fRydbExRdVyY9CdvVZJZ.jpg', 40.00, 100.00, 0.00, 0.00, 'Instant', NULL, 1, 0, '2026-09-17 12:37:01', '2026-09-17 12:37:01');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_method_fields`
--

CREATE TABLE `withdraw_method_fields` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `method_id` bigint(20) UNSIGNED NOT NULL,
  `field_name` varchar(255) NOT NULL,
  `field_label` varchar(255) NOT NULL,
  `field_type` enum('text','number','email','textarea','select') NOT NULL DEFAULT 'text',
  `placeholder` varchar(255) DEFAULT NULL,
  `is_required` tinyint(1) NOT NULL DEFAULT 1,
  `validation_rule` varchar(255) DEFAULT NULL,
  `sort_order` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `withdraw_method_fields`
--

INSERT INTO `withdraw_method_fields` (`id`, `method_id`, `field_name`, `field_label`, `field_type`, `placeholder`, `is_required`, `validation_rule`, `sort_order`, `created_at`, `updated_at`) VALUES
(1, 1, 'cashtag_tag', 'Cashtag/ Tag', 'text', '$yourcashtag', 1, NULL, 1, '2026-08-01 12:55:11', '2026-09-17 12:35:01'),
(3, 2, 'lucinda_cantu_3', '$Lucinda-Cantu-3', 'text', 'John Doe', 1, NULL, 2, '2026-08-01 12:55:11', '2026-09-17 12:35:35'),
(4, 3, 'address', 'Address', 'text', '@username', 1, NULL, 1, '2026-08-01 12:55:11', '2026-09-17 12:36:09'),
(5, 4, 'mail', 'Mail', 'email', NULL, 1, NULL, 0, '2026-09-17 12:37:01', '2026-09-17 12:37:01'),
(6, 4, 'phone_number', 'Phone Number', 'text', NULL, 1, NULL, 0, '2026-09-17 12:37:02', '2026-09-17 12:37:02'),
(7, 4, 'name_on_zelle', 'Name on Zelle', 'text', NULL, 1, NULL, 0, '2026-09-17 12:37:02', '2026-09-17 12:37:02');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_requests`
--

CREATE TABLE `withdraw_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `method_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `fee_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `receive_amount` decimal(12,2) NOT NULL,
  `account_details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`account_details`)),
  `proof_url` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `processed_by` bigint(20) UNSIGNED DEFAULT NULL,
  `processed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `audit_logs_admin_id_foreign` (`admin_id`);

--
-- Indexes for table `backups`
--
ALTER TABLE `backups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `backups_created_by_foreign` (`created_by`),
  ADD KEY `backups_created_at_index` (`created_at`),
  ADD KEY `backups_type_status_index` (`type`,`status`);

--
-- Indexes for table `backup_downloads`
--
ALTER TABLE `backup_downloads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `backup_downloads_admin_id_foreign` (`admin_id`),
  ADD KEY `backup_downloads_created_at_index` (`created_at`),
  ADD KEY `backup_downloads_backup_id_index` (`backup_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_expiration_index` (`expiration`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_locks_expiration_index` (`expiration`);

--
-- Indexes for table `email_templates`
--
ALTER TABLE `email_templates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email_templates_trigger_event_index` (`trigger_event`);

--
-- Indexes for table `export_requests`
--
ALTER TABLE `export_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `export_requests_reviewed_by_foreign` (`reviewed_by`),
  ADD KEY `export_requests_created_at_index` (`created_at`),
  ADD KEY `export_requests_manager_id_status_index` (`manager_id`,`status`),
  ADD KEY `export_requests_status_index` (`status`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `fast_payment_api_logs`
--
ALTER TABLE `fast_payment_api_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fast_payment_api_logs_fast_payment_transaction_id_foreign` (`fast_payment_transaction_id`),
  ADD KEY `fast_payment_api_logs_created_at_index` (`created_at`),
  ADD KEY `fast_payment_api_logs_action_index` (`action`);

--
-- Indexes for table `fast_payment_transactions`
--
ALTER TABLE `fast_payment_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `fast_payment_transactions_order_sn_unique` (`order_sn`),
  ADD KEY `fast_payment_transactions_transaction_id_foreign` (`transaction_id`),
  ADD KEY `fast_payment_transactions_user_id_foreign` (`user_id`),
  ADD KEY `fast_payment_transactions_payment_status_index` (`payment_status`),
  ADD KEY `fast_payment_transactions_fast_transaction_id_index` (`fast_transaction_id`);

--
-- Indexes for table `games`
--
ALTER TABLE `games`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `game_accounts`
--
ALTER TABLE `game_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `game_accounts_game_id_foreign` (`game_id`),
  ADD KEY `game_accounts_assigned_to_foreign` (`assigned_to`);

--
-- Indexes for table `game_api_logs`
--
ALTER TABLE `game_api_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `game_api_logs_created_at_index` (`created_at`),
  ADD KEY `game_api_logs_provider_id_index` (`provider_id`),
  ADD KEY `game_api_logs_action_index` (`action`);

--
-- Indexes for table `game_api_providers`
--
ALTER TABLE `game_api_providers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `game_api_providers_name_unique` (`name`);

--
-- Indexes for table `game_api_provider_secrets`
--
ALTER TABLE `game_api_provider_secrets`
  ADD PRIMARY KEY (`provider_id`),
  ADD KEY `game_api_provider_secrets_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `game_provider_assignments`
--
ALTER TABLE `game_provider_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `game_provider_assignments_game_id_unique` (`game_id`),
  ADD KEY `game_provider_assignments_provider_id_foreign` (`provider_id`);

--
-- Indexes for table `game_unlock_requests`
--
ALTER TABLE `game_unlock_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `game_unlock_requests_user_id_foreign` (`user_id`),
  ADD KEY `game_unlock_requests_game_id_foreign` (`game_id`),
  ADD KEY `game_unlock_requests_approved_by_foreign` (`approved_by`),
  ADD KEY `game_unlock_requests_game_account_id_foreign` (`game_account_id`);

--
-- Indexes for table `ghl_api_logs`
--
ALTER TABLE `ghl_api_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ghl_api_logs_created_at_index` (`created_at`),
  ADD KEY `ghl_api_logs_user_id_index` (`user_id`),
  ADD KEY `ghl_api_logs_action_index` (`action`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `manual_verification_requests`
--
ALTER TABLE `manual_verification_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `manual_verification_requests_reviewed_by_foreign` (`reviewed_by`),
  ADD KEY `manual_verification_requests_type_status_index` (`type`,`status`),
  ADD KEY `manual_verification_requests_user_id_index` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_user_id_foreign` (`user_id`);

--
-- Indexes for table `otp_verifications`
--
ALTER TABLE `otp_verifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `otp_verifications_user_id_foreign` (`user_id`);

--
-- Indexes for table `password_requests`
--
ALTER TABLE `password_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `password_requests_user_id_foreign` (`user_id`),
  ADD KEY `password_requests_game_account_id_foreign` (`game_account_id`),
  ADD KEY `password_requests_reviewed_by_foreign` (`reviewed_by`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_gateway_accounts`
--
ALTER TABLE `payment_gateway_accounts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_gateway_accounts_gateway_id_foreign` (`gateway_id`);

--
-- Indexes for table `recovery_configs`
--
ALTER TABLE `recovery_configs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `recovery_configs_updated_by_foreign` (`updated_by`);

--
-- Indexes for table `rewards_config`
--
ALTER TABLE `rewards_config`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `rewards_config_key_unique` (`key`);

--
-- Indexes for table `reward_history`
--
ALTER TABLE `reward_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reward_history_user_id_foreign` (`user_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `site_settings`
--
ALTER TABLE `site_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_channels`
--
ALTER TABLE `support_channels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `transactions_idempotency_key_unique` (`idempotency_key`),
  ADD KEY `transactions_user_id_foreign` (`user_id`),
  ADD KEY `transactions_game_id_foreign` (`game_id`),
  ADD KEY `transactions_reviewed_by_foreign` (`reviewed_by`),
  ADD KEY `transactions_gateway_id_foreign` (`gateway_id`),
  ADD KEY `transactions_gateway_account_id_foreign` (`gateway_account_id`);

--
-- Indexes for table `transaction_logs`
--
ALTER TABLE `transaction_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaction_logs_transaction_id_foreign` (`transaction_id`),
  ADD KEY `transaction_logs_action_by_foreign` (`action_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `users_legacy_id_unique` (`legacy_id`);

--
-- Indexes for table `verification_settings`
--
ALTER TABLE `verification_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `withdraw_methods_code_unique` (`code`);

--
-- Indexes for table `withdraw_method_fields`
--
ALTER TABLE `withdraw_method_fields`
  ADD PRIMARY KEY (`id`),
  ADD KEY `withdraw_method_fields_method_id_foreign` (`method_id`);

--
-- Indexes for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `withdraw_requests_user_id_foreign` (`user_id`),
  ADD KEY `withdraw_requests_method_id_foreign` (`method_id`),
  ADD KEY `withdraw_requests_processed_by_foreign` (`processed_by`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=93;

--
-- AUTO_INCREMENT for table `backups`
--
ALTER TABLE `backups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `backup_downloads`
--
ALTER TABLE `backup_downloads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `email_templates`
--
ALTER TABLE `email_templates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `export_requests`
--
ALTER TABLE `export_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fast_payment_api_logs`
--
ALTER TABLE `fast_payment_api_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fast_payment_transactions`
--
ALTER TABLE `fast_payment_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `games`
--
ALTER TABLE `games`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `game_accounts`
--
ALTER TABLE `game_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `game_api_logs`
--
ALTER TABLE `game_api_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `game_api_providers`
--
ALTER TABLE `game_api_providers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `game_provider_assignments`
--
ALTER TABLE `game_provider_assignments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `game_unlock_requests`
--
ALTER TABLE `game_unlock_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `ghl_api_logs`
--
ALTER TABLE `ghl_api_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `manual_verification_requests`
--
ALTER TABLE `manual_verification_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `otp_verifications`
--
ALTER TABLE `otp_verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `password_requests`
--
ALTER TABLE `password_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment_gateways`
--
ALTER TABLE `payment_gateways`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payment_gateway_accounts`
--
ALTER TABLE `payment_gateway_accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `recovery_configs`
--
ALTER TABLE `recovery_configs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rewards_config`
--
ALTER TABLE `rewards_config`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `reward_history`
--
ALTER TABLE `reward_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `site_settings`
--
ALTER TABLE `site_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `support_channels`
--
ALTER TABLE `support_channels`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `transaction_logs`
--
ALTER TABLE `transaction_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=127;

--
-- AUTO_INCREMENT for table `verification_settings`
--
ALTER TABLE `verification_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `withdraw_method_fields`
--
ALTER TABLE `withdraw_method_fields`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `backups`
--
ALTER TABLE `backups`
  ADD CONSTRAINT `backups_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `backup_downloads`
--
ALTER TABLE `backup_downloads`
  ADD CONSTRAINT `backup_downloads_admin_id_foreign` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `backup_downloads_backup_id_foreign` FOREIGN KEY (`backup_id`) REFERENCES `backups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `export_requests`
--
ALTER TABLE `export_requests`
  ADD CONSTRAINT `export_requests_manager_id_foreign` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `export_requests_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `fast_payment_api_logs`
--
ALTER TABLE `fast_payment_api_logs`
  ADD CONSTRAINT `fast_payment_api_logs_fast_payment_transaction_id_foreign` FOREIGN KEY (`fast_payment_transaction_id`) REFERENCES `fast_payment_transactions` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `fast_payment_transactions`
--
ALTER TABLE `fast_payment_transactions`
  ADD CONSTRAINT `fast_payment_transactions_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fast_payment_transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `game_accounts`
--
ALTER TABLE `game_accounts`
  ADD CONSTRAINT `game_accounts_assigned_to_foreign` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `game_accounts_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `game_api_logs`
--
ALTER TABLE `game_api_logs`
  ADD CONSTRAINT `game_api_logs_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `game_api_providers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `game_api_provider_secrets`
--
ALTER TABLE `game_api_provider_secrets`
  ADD CONSTRAINT `game_api_provider_secrets_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `game_api_providers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `game_api_provider_secrets_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `game_provider_assignments`
--
ALTER TABLE `game_provider_assignments`
  ADD CONSTRAINT `game_provider_assignments_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `game_provider_assignments_provider_id_foreign` FOREIGN KEY (`provider_id`) REFERENCES `game_api_providers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `game_unlock_requests`
--
ALTER TABLE `game_unlock_requests`
  ADD CONSTRAINT `game_unlock_requests_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `game_unlock_requests_game_account_id_foreign` FOREIGN KEY (`game_account_id`) REFERENCES `game_accounts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `game_unlock_requests_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `game_unlock_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ghl_api_logs`
--
ALTER TABLE `ghl_api_logs`
  ADD CONSTRAINT `ghl_api_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `manual_verification_requests`
--
ALTER TABLE `manual_verification_requests`
  ADD CONSTRAINT `manual_verification_requests_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `manual_verification_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `otp_verifications`
--
ALTER TABLE `otp_verifications`
  ADD CONSTRAINT `otp_verifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `password_requests`
--
ALTER TABLE `password_requests`
  ADD CONSTRAINT `password_requests_game_account_id_foreign` FOREIGN KEY (`game_account_id`) REFERENCES `game_accounts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `password_requests_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `password_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_gateway_accounts`
--
ALTER TABLE `payment_gateway_accounts`
  ADD CONSTRAINT `payment_gateway_accounts_gateway_id_foreign` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `recovery_configs`
--
ALTER TABLE `recovery_configs`
  ADD CONSTRAINT `recovery_configs_updated_by_foreign` FOREIGN KEY (`updated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `reward_history`
--
ALTER TABLE `reward_history`
  ADD CONSTRAINT `reward_history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_game_id_foreign` FOREIGN KEY (`game_id`) REFERENCES `games` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `transactions_gateway_account_id_foreign` FOREIGN KEY (`gateway_account_id`) REFERENCES `payment_gateway_accounts` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `transactions_gateway_id_foreign` FOREIGN KEY (`gateway_id`) REFERENCES `payment_gateways` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `transactions_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `transactions_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `transaction_logs`
--
ALTER TABLE `transaction_logs`
  ADD CONSTRAINT `transaction_logs_action_by_foreign` FOREIGN KEY (`action_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transaction_logs_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `withdraw_method_fields`
--
ALTER TABLE `withdraw_method_fields`
  ADD CONSTRAINT `withdraw_method_fields_method_id_foreign` FOREIGN KEY (`method_id`) REFERENCES `withdraw_methods` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `withdraw_requests`
--
ALTER TABLE `withdraw_requests`
  ADD CONSTRAINT `withdraw_requests_method_id_foreign` FOREIGN KEY (`method_id`) REFERENCES `withdraw_methods` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `withdraw_requests_processed_by_foreign` FOREIGN KEY (`processed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `withdraw_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
